const DIRS = [[-1, 0], [0, 1], [1, 0], [0, -1]];

export function mountGroupA(mode, ctx) {
  const { board, rng, tier, audio, onMove, onWin, toast } = ctx;
  const size = tier < 2 ? 3 : tier < 6 ? 4 : 5;

  // 1 & 2: path_classic & path_checkpoint
  if (mode === 'path_classic' || mode === 'path_checkpoint') {
    const targetLen = Math.min(size * size, Math.max(5, Math.floor(size * size * (0.6 + tier * 0.035))));
    let best = [];
    for (let a = 0; a < 20; a++) {
      const sr = Math.floor(rng() * size), sc = Math.floor(rng() * size);
      const vis = Array.from({ length: size }, () => Array(size).fill(false));
      const p = [[sr, sc]]; vis[sr][sc] = true;
      let st = 0;
      const dfs = (r, c) => {
        if (p.length >= targetLen || st++ > 180) return true;
        for (const d of [0, 1, 2, 3].sort(() => rng() - 0.5)) {
          const nr = r + DIRS[d][0], nc = c + DIRS[d][1];
          if (nr >= 0 && nr < size && nc >= 0 && nc < size && !vis[nr][nc]) {
            vis[nr][nc] = true; p.push([nr, nc]);
            if (dfs(nr, nc)) return true;
            p.pop(); vis[nr][nc] = false;
          }
        }
        return false;
      };
      dfs(sr, sc);
      if (p.length > best.length) best = p.slice();
      if (best.length >= targetLen) break;
    }
    const openSet = new Set(best.map(([r, c]) => `${r},${c}`));
    const cps = mode === 'path_checkpoint' ? [best[Math.floor(best.length / 3)], best[Math.floor(best.length * 2 / 3)], best[best.length - 1]] : [];
    let trail = [best[0].slice()];
    let dragging = false;

    const render = () => {
      board.innerHTML = '';
      board.style.gridTemplateColumns = `repeat(${size}, 1fr)`;
      const tMap = new Map(trail.map(([r, c], i) => [`${r},${c}`, i]));
      const head = trail[trail.length - 1];
      for (let r = 0; r < size; r++) {
        for (let c = 0; c < size; c++) {
          const el = document.createElement('div');
          el.className = 'tile'; el.dataset.r = r; el.dataset.c = c;
          const k = `${r},${c}`;
          if (!openSet.has(k)) { el.classList.add('wall'); }
          else {
            const idx = tMap.get(k);
            const cpIdx = cps.findIndex(([cr, cc]) => cr === r && cc === c);
            if (r === best[0][0] && c === best[0][1]) el.classList.add('path-start');
            if (idx !== undefined) {
              el.classList.add(head[0] === r && head[1] === c ? 'path-head' : 'path-active');
              el.textContent = idx === 0 ? '▶' : (cpIdx >= 0 ? `🚩${cpIdx + 1}` : idx + 1);
            } else if (cpIdx >= 0) {
              el.textContent = `🚩${cpIdx + 1}`;
              el.style.borderColor = 'var(--warn)';
            }
            el.onpointerdown = (e) => { e.preventDefault(); dragging = true; step(r, c); };
          }
          board.appendChild(el);
        }
      }
    };

    const step = (r, c) => {
      if (!openSet.has(`${r},${c}`)) return;
      const head = trail[trail.length - 1];
      if (head[0] === r && head[1] === c) return;
      if (trail.length >= 2 && trail[trail.length - 2][0] === r && trail[trail.length - 2][1] === c) {
        trail.pop(); audio.playTap(-2); render(); return;
      }
      if (Math.abs(head[0] - r) + Math.abs(head[1] - c) === 1 && !trail.some(([pr, pc]) => pr === r && pc === c)) {
        trail.push([r, c]); onMove(); audio.playTap(trail.length); render();
        if (trail.length === best.length) {
          if (mode === 'path_checkpoint') {
            const idxs = cps.map(([cr, cc]) => trail.findIndex(([tr, tc]) => tr === cr && tc === cc));
            if (!(idxs[0] < idxs[1] && idxs[1] < idxs[2])) {
              audio.playError(); toast('চেকপয়েন্ট ১ → ২ → ৩ ক্রমে পার হতে হবে!'); return;
            }
          }
          setTimeout(() => onWin(best.length), 180);
        }
      }
    };
    board.onpointermove = (e) => {
      if (!dragging) return;
      const el = document.elementFromPoint(e.clientX, e.clientY);
      if (el?.dataset?.r !== undefined) step(Number(el.dataset.r), Number(el.dataset.c));
    };
    window.addEventListener('pointerup', () => (dragging = false), { once: false });
    render();
    return {
      reset: () => { trail = [best[0].slice()]; render(); },
      hint: () => {
        const next = best[Math.min(best.length - 1, trail.length)];
        if (next) step(next[0], next[1]);
      }
    };
  }

  // 3. path_ice (Ice Slide)
  if (mode === 'path_ice') {
    const s = Math.min(6, Math.max(4, size + 1));
    const grid = Array.from({ length: s }, () => Array(s).fill(0));
    let pr = 0, pc = 0;
    // Generate solvable slide path by placing blockers
    let cr = 0, cc = 0;
    const rocks = new Set();
    for (let k = 0; k < 4 + Math.min(3, tier); k++) {
      const d = k % 2 === 0 ? (cc < s - 2 ? 1 : 3) : (cr < s - 2 ? 2 : 0);
      const dist = 1 + Math.floor(rng() * (s - 2));
      for (let i = 0; i < dist; i++) {
        const nr = cr + DIRS[d][0], nc = cc + DIRS[d][1];
        if (nr < 0 || nr >= s || nc < 0 || nc >= s || rocks.has(`${nr},${nc}`)) break;
        cr = nr; cc = nc;
      }
      const br = cr + DIRS[d][0], bc = cc + DIRS[d][1];
      if (br >= 0 && br < s && bc >= 0 && bc < s && !(br === 0 && bc === 0)) rocks.add(`${br},${bc}`);
    }
    if (cr === 0 && cc === 0) { cr = s - 1; cc = s - 1; }
    const goal = [cr, cc];
    rocks.delete(`${goal[0]},${goal[1]}`);

    const render = () => {
      board.innerHTML = '';
      board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
      for (let r = 0; r < s; r++) {
        for (let c = 0; c < s; c++) {
          const el = document.createElement('div');
          el.className = 'tile';
          if (rocks.has(`${r},${c}`)) { el.textContent = '🪨'; el.style.background = 'var(--surface-2)'; }
          else if (r === pr && c === pc) { el.textContent = '🧊'; el.classList.add('path-head'); }
          else if (r === goal[0] && c === goal[1]) { el.textContent = '🏁'; el.style.borderColor = 'var(--accent-2)'; }
          board.appendChild(el);
        }
      }
      // D-pad below grid
      const pad = document.createElement('div');
      pad.style.cssText = 'grid-column: 1 / -1; display:flex; justify-content:center; gap:10px; margin-top:8px;';
      [['⬆️', 0], ['⬅️', 3], ['⬇️', 2], ['➡️', 1]].forEach(([lbl, d]) => {
        const b = document.createElement('button');
        b.className = 'ctrl-btn'; b.style.width = '56px'; b.textContent = lbl;
        b.onclick = () => slide(d);
        pad.appendChild(b);
      });
      board.appendChild(pad);
    };
    const slide = (d) => {
      let moved = false;
      while (true) {
        const nr = pr + DIRS[d][0], nc = pc + DIRS[d][1];
        if (nr < 0 || nr >= s || nc < 0 || nc >= s || rocks.has(`${nr},${nc}`)) break;
        pr = nr; pc = nc; moved = true;
        if (pr === goal[0] && pc === goal[1]) break;
      }
      if (moved) { onMove(); audio.playTap(3); render(); if (pr === goal[0] && pc === goal[1]) setTimeout(() => onWin(6), 200); }
    };
    render();
    return { reset: () => { pr = 0; pc = 0; render(); }, hint: () => toast(`লক্ষ্য: সারি ${goal[0] + 1}, কলাম ${goal[1] + 1}`) };
  }

  // 4. path_knight (Chess Knight L-jumps)
  if (mode === 'path_knight') {
    const s = Math.max(4, size);
    const kDirs = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
    let kr = Math.floor(rng() * s), kc = Math.floor(rng() * s);
    const seq = [[kr, kc]];
    const used = new Set([`${kr},${kc}`]);
    const targetStars = Math.min(8, 3 + Math.floor(tier / 2));
    for (let i = 0; i < targetStars; i++) {
      const cands = kDirs.map(([dr, dc]) => [kr + dr, kc + dc]).filter(([r, c]) => r >= 0 && r < s && c >= 0 && c < s && !used.has(`${r},${c}`));
      if (!cands.length) break;
      const [nr, nc] = cands[Math.floor(rng() * cands.length)];
      used.add(`${nr},${nc}`); seq.push([nr, nc]); kr = nr; kc = nc;
    }
    let pos = seq[0].slice();
    let stars = new Set(seq.slice(1).map(([r, c]) => `${r},${c}`));
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
      for (let r = 0; r < s; r++) {
        for (let c = 0; c < s; c++) {
          const el = document.createElement('div');
          el.className = 'tile';
          const isValid = Math.abs(r - pos[0]) * Math.abs(c - pos[1]) === 2;
          if (r === pos[0] && c === pos[1]) { el.textContent = '♞'; el.classList.add('path-head'); }
          else if (stars.has(`${r},${c}`)) { el.textContent = '⭐'; el.style.borderColor = 'var(--warn)'; }
          if (isValid) el.style.background = 'rgba(6,182,212,0.16)';
          el.onclick = () => {
            if (!isValid) { audio.playError(); return; }
            pos = [r, c]; stars.delete(`${r},${c}`); onMove(); audio.playTap(4); render();
            if (stars.size === 0) setTimeout(() => onWin(seq.length), 200);
          };
          board.appendChild(el);
        }
      }
    };
    render();
    return { reset: () => { pos = seq[0].slice(); stars = new Set(seq.slice(1).map(([r, c]) => `${r},${c}`)); render(); }, hint: () => toast('নীল হাইলাইট করা ঘরগুলোতে ঘোড়া লাফ দিতে পারে!') };
  }

  // 5. path_maze (Dark Maze with Fog of War)
  if (mode === 'path_maze') {
    const s = 5;
    const walls = new Set();
    const vis = Array.from({ length: s }, () => Array(s).fill(false));
    const path = [[0, 0]]; vis[0][0] = true;
    let r = 0, c = 0;
    while (r < s - 1 || c < s - 1) {
      if (r < s - 1 && (c === s - 1 || rng() > 0.5)) r++; else c++;
      vis[r][c] = true; path.push([r, c]);
    }
    for (let i = 0; i < s; i++) for (let j = 0; j < s; j++) if (!vis[i][j] && rng() > 0.45) walls.add(`${i},${j}`);
    let pos = [0, 0];
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
      for (let i = 0; i < s; i++) {
        for (let j = 0; j < s; j++) {
          const el = document.createElement('div');
          el.className = 'tile';
          const dist = Math.abs(i - pos[0]) + Math.abs(j - pos[1]);
          if (dist > 1 && !(i === s - 1 && j === s - 1)) {
            el.style.background = '#020617'; el.textContent = '?'; el.style.color = '#334155';
          } else if (walls.has(`${i},${j}`)) {
            el.textContent = '🧱'; el.style.background = 'var(--surface-2)';
          } else if (i === pos[0] && j === pos[1]) {
            el.textContent = '🔦'; el.classList.add('path-head');
          } else if (i === s - 1 && j === s - 1) {
            el.textContent = '🏁'; el.style.borderColor = 'var(--accent-2)';
          }
          el.onclick = () => {
            if (dist === 1 && !walls.has(`${i},${j}`)) {
              pos = [i, j]; onMove(); audio.playTap(2); render();
              if (i === s - 1 && j === s - 1) setTimeout(() => onWin(s * 2), 180);
            }
          };
          board.appendChild(el);
        }
      }
    };
    render();
    return { reset: () => { pos = [0, 0]; render(); }, hint: () => toast('ডান ও নিচের দিকে এগিয়ে 🏁 পতাকায় যান!') };
  }

  // 6, 7, 8, 9: flip_plus, flip_cross, flip_rowcol, flip_tricolor
  if (mode === 'flip_plus' || mode === 'flip_cross' || mode === 'flip_rowcol' || mode === 'flip_tricolor') {
    const isTri = mode === 'flip_tricolor';
    const maxState = isTri ? 2 : 1;
    const grid = Array.from({ length: size }, () => Array(size).fill(maxState));
    const applyFlip = (g, r, c, step = 1) => {
      const nextVal = (v) => (v + step) % (maxState + 1);
      if (mode === 'flip_rowcol') {
        for (let i = 0; i < size; i++) { g[r][i] = nextVal(g[r][i]); if (i !== r) g[i][c] = nextVal(g[i][c]); }
      } else {
        const offs = mode === 'flip_cross' ? [[0,0],[-1,-1],[-1,1],[1,-1],[1,1]] : [[0,0],[-1,0],[1,0],[0,-1],[0,1]];
        for (const [dr, dc] of offs) {
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < size && nc >= 0 && nc < size) g[nr][nc] = nextVal(g[nr][nc]);
        }
      }
    };
    const sol = [];
    const cnt = Math.min(size * size - 1, 2 + Math.floor(tier / 2));
    for (let i = 0; i < cnt; i++) {
      const r = Math.floor(rng() * size), c = Math.floor(rng() * size);
      applyFlip(grid, r, c, isTri ? 2 : 1);
      sol.push([r, c]);
    }
    const initCopy = grid.map((r) => r.slice());
    let cur = grid.map((r) => r.slice());
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${size}, 1fr)`;
      for (let r = 0; r < size; r++) {
        for (let c = 0; c < size; c++) {
          const el = document.createElement('div');
          const v = cur[r][c];
          el.className = 'tile';
          if (isTri) {
            el.style.background = v === 2 ? '#10b981' : v === 1 ? '#f59e0b' : '#ef4444';
            el.textContent = v === 2 ? '🟢' : v === 1 ? '🟡' : '🔴';
          } else {
            el.classList.add(v === 1 ? 'light-on' : 'light-off');
            el.textContent = v === 1 ? '💡' : '○';
          }
          el.onclick = () => {
            applyFlip(cur, r, c, 1); onMove(); audio.playTap(v * 2); render();
            if (cur.every((row) => row.every((x) => x === maxState))) setTimeout(() => onWin(sol.length), 200);
          };
          board.appendChild(el);
        }
      }
    };
    render();
    return { reset: () => { cur = initCopy.map((r) => r.slice()); render(); }, hint: () => toast(`সারি ${sol[0][0] + 1}, কলাম ${sol[0][1] + 1} ট্যাপ করে দেখুন!`) };
  }

  // 10. flip_mirror (Mirror Symmetry)
  const cols = 4, rows = Math.min(5, Math.max(3, size));
  const left = Array.from({ length: rows }, () => Array.from({ length: 2 }, () => (rng() > 0.45 ? 1 : 0)));
  if (left.every((r) => r.every((v) => v === 0))) left[0][0] = 1;
  let right = Array.from({ length: rows }, () => [0, 0]);
  const render = () => {
    board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const el = document.createElement('div');
        el.className = 'tile';
        if (c < 2) {
          el.style.pointerEvents = 'none';
          if (left[r][c]) { el.classList.add('path-active'); el.textContent = '■'; }
        } else {
          const rc = c - 2;
          if (right[r][rc]) { el.classList.add('path-head'); el.textContent = '■'; }
          el.onclick = () => {
            right[r][rc] = right[r][rc] ? 0 : 1; onMove(); audio.playTap(3); render();
            const ok = left.every((row, ri) => row[0] === right[ri][1] && row[1] === right[ri][0]);
            if (ok) setTimeout(() => onWin(rows * 2), 200);
          };
        }
        board.appendChild(el);
      }
    }
  };
  render();
  return { reset: () => { right = Array.from({ length: rows }, () => [0, 0]); render(); }, hint: () => toast('বামের ১ম কলাম → ডানের শেষ কলাম, বামের ২য় → ডানের ১ম!') };
}
