import { createRng, getLevelMeta } from './config.js';

const DIRS = [
  [-1, 0], // 0: Up
  [0, 1],  // 1: Right
  [1, 0],  // 2: Down
  [0, -1]  // 3: Left
];

// 1. ONE-LINE PATH (Hamiltonian Path Carving — 100% Solvable)
function generatePathPuzzle(size, level, rng) {
  const totalCells = size * size;
  const targetLen = Math.min(
    totalCells,
    Math.max(4, Math.floor(totalCells * (0.55 + Math.min(0.42, level / 700))))
  );

  let bestPath = [];
  for (let attempt = 0; attempt < 25; attempt++) {
    const startR = Math.floor(rng() * size);
    const startC = Math.floor(rng() * size);
    const visited = Array.from({ length: size }, () => Array(size).fill(false));
    const path = [[startR, startC]];
    visited[startR][startC] = true;

    let steps = 0;
    const dfs = (r, c) => {
      if (path.length >= targetLen || steps > 220) return true;
      steps++;
      const order = [0, 1, 2, 3].sort(() => rng() - 0.5);
      for (const d of order) {
        const nr = r + DIRS[d][0];
        const nc = c + DIRS[d][1];
        if (nr >= 0 && nr < size && nc >= 0 && nc < size && !visited[nr][nc]) {
          visited[nr][nc] = true;
          path.push([nr, nc]);
          if (dfs(nr, nc)) return true;
          path.pop();
          visited[nr][nc] = false;
        }
      }
      return false;
    };

    dfs(startR, startC);
    if (path.length > bestPath.length) bestPath = path.slice();
    if (bestPath.length >= targetLen) break;
  }

  const activeSet = new Set(bestPath.map(([r, c]) => `${r},${c}`));
  const grid = Array.from({ length: size }, (_, r) =>
    Array.from({ length: size }, (_, c) => (activeSet.has(`${r},${c}`) ? 1 : 0))
  );

  return {
    type: 'path',
    size,
    grid, // 1 = open, 0 = wall
    start: bestPath[0],
    solution: bestPath,
    parMoves: bestPath.length - 1
  };
}

// 2. QUANTUM FLIP (Lights Out — Reverse-engineered from solved state, 100% Solvable)
function generateLightsPuzzle(size, level, rng) {
  const grid = Array.from({ length: size }, () => Array(size).fill(1));
  const useDiagonal = level > 260 && level % 10 === 2; // Special X-pattern in high levels!
  const movesCount = Math.min(
    size * size - 1,
    Math.max(2, Math.floor(2 + (level / 55)))
  );

  const toggle = (g, r, c) => {
    const offsets = useDiagonal
      ? [[0, 0], [-1, -1], [-1, 1], [1, -1], [1, 1]]
      : [[0, 0], [-1, 0], [1, 0], [0, -1], [0, 1]];
    for (const [dr, dc] of offsets) {
      const nr = r + dr;
      const nc = c + dc;
      if (nr >= 0 && nr < size && nc >= 0 && nc < size) {
        g[nr][nc] = g[nr][nc] ? 0 : 1;
      }
    }
  };

  const chosen = [];
  const used = new Set();
  for (let i = 0; i < movesCount; i++) {
    let r, c, key;
    for (let t = 0; t < 30; t++) {
      r = Math.floor(rng() * size);
      c = Math.floor(rng() * size);
      key = `${r},${c}`;
      if (!used.has(key)) break;
    }
    if (!used.has(key)) {
      used.add(key);
      chosen.push([r, c]);
      toggle(grid, r, c);
    }
  }

  // Ensure not accidentally already solved
  if (grid.every((row) => row.every((v) => v === 1))) {
    toggle(grid, 0, 0);
    chosen.push([0, 0]);
  }

  return {
    type: 'lights',
    size,
    grid,
    useDiagonal,
    solution: chosen,
    parMoves: chosen.length
  };
}

// 3. CIRCUIT ROTATE (Pipe Network — Spanning Tree from Source to Targets, 100% Solvable)
function generatePipesPuzzle(size, level, rng) {
  const total = size * size;
  const visited = Array.from({ length: size }, () => Array(size).fill(false));
  const mask = Array.from({ length: size }, () => Array(size).fill(0)); // bitmask: 1=U, 2=R, 4=D, 8=L

  const sr = Math.floor(rng() * size);
  const sc = Math.floor(rng() * size);
  visited[sr][sc] = true;

  const stack = [[sr, sc]];
  const leaves = [];
  const maxNodes = Math.min(total, Math.max(5, Math.floor(total * (0.6 + Math.min(0.38, level / 650)))));
  let nodeCount = 1;

  while (stack.length > 0 && nodeCount < maxNodes) {
    const idx = rng() > 0.3 ? stack.length - 1 : Math.floor(rng() * stack.length);
    const [r, c] = stack[idx];
    const neighbors = [];
    for (let d = 0; d < 4; d++) {
      const nr = r + DIRS[d][0];
      const nc = c + DIRS[d][1];
      if (nr >= 0 && nr < size && nc >= 0 && nc < size && !visited[nr][nc]) {
        neighbors.push([nr, nc, d]);
      }
    }
    if (neighbors.length === 0) {
      stack.splice(idx, 1);
    } else {
      const [nr, nc, d] = neighbors[Math.floor(rng() * neighbors.length)];
      const opp = (d + 2) % 4;
      mask[r][c] |= (1 << d);
      mask[nr][nc] |= (1 << opp);
      visited[nr][nc] = true;
      nodeCount++;
      stack.push([nr, nc]);
    }
  }

  // Find leaf nodes as energy targets (excluding source)
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (r === sr && c === sc) continue;
      const m = mask[r][c];
      if (m === 1 || m === 2 || m === 4 || m === 8) leaves.push([r, c]);
    }
  }

  // Rotate bitmask clockwise by rot*90 deg
  const rotMask = (m, rot) => {
    let res = m;
    for (let i = 0; i < rot; i++) {
      let next = 0;
      if (res & 1) next |= 2;
      if (res & 2) next |= 4;
      if (res & 4) next |= 8;
      if (res & 8) next |= 1;
      res = next;
    }
    return res;
  };

  // Build scrambled rotations
  const currentMasks = Array.from({ length: size }, () => Array(size).fill(0));
  const targetMasks = mask.map((row) => row.slice());
  let scrambleCount = 0;

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const m = mask[r][c];
      if (m === 0 || m === 15) {
        currentMasks[r][c] = m;
        continue;
      }
      const rot = 1 + Math.floor(rng() * 3);
      const scrambled = rotMask(m, rot);
      currentMasks[r][c] = scrambled;
      if (scrambled !== m) scrambleCount++;
    }
  }

  return {
    type: 'pipes',
    size,
    source: [sr, sc],
    targets: leaves,
    currentMasks,
    targetMasks,
    parMoves: Math.max(4, Math.ceil(scrambleCount * 1.5))
  };
}

// 4. SUM MATRIX (Numerical Deduction Grid — 100% Solvable)
function generateSumGridPuzzle(size, level, rng) {
  const maxVal = level < 80 ? 5 : level < 220 ? 9 : 12;
  const values = Array.from({ length: size }, () =>
    Array.from({ length: size }, () => 1 + Math.floor(rng() * maxVal))
  );

  // Pick a random non-empty subset as the solution
  const solution = Array.from({ length: size }, () => Array(size).fill(0));
  let activeCount = 0;
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (rng() > 0.45) {
        solution[r][c] = 1;
        activeCount++;
      }
    }
  }
  if (activeCount < 2) {
    solution[0][0] = 1;
    solution[size - 1][size - 1] = 1;
    activeCount = 2;
  }

  const rowTargets = Array.from({ length: size }, (_, r) =>
    values[r].reduce((acc, v, c) => acc + (solution[r][c] ? v : 0), 0)
  );
  const colTargets = Array.from({ length: size }, (_, c) =>
    values.reduce((acc, row, r) => acc + (solution[r][c] ? row[c] : 0), 0)
  );

  return {
    type: 'sumgrid',
    size,
    values,
    rowTargets,
    colTargets,
    solution,
    parMoves: activeCount + 2
  };
}

// 5. MEMORY MATRIX (Spatial Recall & Ordered Sequence Recall)
function generateMemoryPuzzle(size, level, rng) {
  const ordered = level > 90 && (Math.floor(level / 5) % 2 === 1);
  const count = Math.min(
    size * size - 2,
    Math.max(3, Math.floor(3 + level / 52))
  );

  const cells = [];
  const used = new Set();
  while (cells.length < count) {
    const r = Math.floor(rng() * size);
    const c = Math.floor(rng() * size);
    const key = `${r},${c}`;
    if (!used.has(key)) {
      used.add(key);
      cells.push([r, c]);
    }
  }

  const previewMs = Math.max(1400, 3200 - Math.floor(level * 3));

  return {
    type: 'memory',
    size,
    ordered,
    sequence: cells,
    previewMs,
    parMoves: cells.length
  };
}

export function generateLevel(levelNum) {
  const meta = getLevelMeta(levelNum);
  const rng = createRng(levelNum * 2654435761 + 1013904223);

  let data;
  if (meta.mode === 'path') data = generatePathPuzzle(meta.size, levelNum, rng);
  else if (meta.mode === 'lights') data = generateLightsPuzzle(meta.size, levelNum, rng);
  else if (meta.mode === 'pipes') data = generatePipesPuzzle(meta.size, levelNum, rng);
  else if (meta.mode === 'sumgrid') data = generateSumGridPuzzle(meta.size, levelNum, rng);
  else data = generateMemoryPuzzle(meta.size, levelNum, rng);

  return { ...meta, ...data };
}
