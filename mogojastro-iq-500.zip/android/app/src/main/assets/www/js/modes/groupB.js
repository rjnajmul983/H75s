const DIRS = [[-1, 0], [0, 1], [1, 0], [0, -1]];

export function mountGroupB(mode, ctx) {
  const { board, rng, tier, audio, onMove, onWin, toast } = ctx;
  const size = tier < 2 ? 3 : tier < 6 ? 4 : 5;

  // 11 & 12: pipe_circuit & pipe_dual
  if (mode === 'pipe_circuit' || mode === 'pipe_dual') {
    const visited = Array.from({ length: size }, () => Array(size).fill(false));
    const mask = Array.from({ length: size }, () => Array(size).fill(0));
    const sr = Math.floor(rng() * size), sc = Math.floor(rng() * size);
    visited[sr][sc] = true;
    const stack = [[sr, sc]];
    const maxN = Math.min(size * size, Math.max(5, Math.floor(size * size * 0.8)));
    let cnt = 1;
    while (stack.length && cnt < maxN) {
      const [r, c] = stack[stack.length - 1];
      const nbs = DIRS.map(([dr, dc], d) => [r + dr, c + dc, d]).filter(([nr, nc]) => nr >= 0 && nr < size && nc >= 0 && nc < size && !visited[nr][nc]);
      if (!nbs.length) stack.pop();
      else {
        const [nr, nc, d] = nbs[Math.floor(rng() * nbs.length)];
        mask[r][c] |= (1 << d); mask[nr][nc] |= (1 << ((d + 2) % 4));
        visited[nr][nc] = true; cnt++; stack.push([nr, nc]);
      }
    }
    const leaves = [];
    for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) {
      if ((r !== sr || c !== sc) && [1, 2, 4, 8].includes(mask[r][c])) leaves.push([r, c]);
    }
    const rotM = (m, k) => {
      let x = m;
      for (let i = 0; i < k; i++) x = ((x & 1) ? 2 : 0) | ((x & 2) ? 4 : 0) | ((x & 4) ? 8 : 0) | ((x & 8) ? 1 : 0);
      return x;
    };
    const init = mask.map((row) => row.map((m) => (m === 0 || m === 15 ? m : rotM(m, 1 + Math.floor(rng() * 3)))));
    let cur = init.map((r) => r.slice());

    const calcPow = () => {
      const pow = Array.from({ length: size }, () => Array(size).fill(false));
      const q = [[sr, sc]]; pow[sr][sc] = true;
      const ds = [[-1,0,1,4],[0,1,2,8],[1,0,4,1],[0,-1,8,2]];
      while (q.length) {
        const [r, c] = q.shift();
        for (const [dr, dc, mb, ob] of ds) {
          if (!(cur[r][c] & mb)) continue;
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < size && nc >= 0 && nc < size && !pow[nr][nc] && (cur[nr][nc] & ob)) {
            pow[nr][nc] = true; q.push([nr, nc]);
          }
        }
      }
      return pow;
    };

    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${size}, 1fr)`;
      const pow = calcPow();
      for (let r = 0; r < size; r++) {
        for (let c = 0; c < size; c++) {
          const el = document.createElement('div');
          const m = cur[r][c];
          el.className = 'tile pipe-tile';
          if (m === 0) el.classList.add('wall');
          else {
            const isS = r === sr && c === sc;
            const isT = leaves.some(([tr, tc]) => tr === r && tc === c);
            if (pow[r][c]) el.classList.add('pipe-powered');
            const st = pow[r][c] ? '#06b6d4' : '#64748b';
            let ln = '';
            if (m & 1) ln += `<line x1="50" y1="50" x2="50" y2="0" stroke="${st}" stroke-width="18" stroke-linecap="round"/>`;
            if (m & 2) ln += `<line x1="50" y1="50" x2="100" y2="50" stroke="${st}" stroke-width="18" stroke-linecap="round"/>`;
            if (m & 4) ln += `<line x1="50" y1="50" x2="50" y2="100" stroke="${st}" stroke-width="18" stroke-linecap="round"/>`;
            if (m & 8) ln += `<line x1="50" y1="50" x2="0" y2="50" stroke="${st}" stroke-width="18" stroke-linecap="round"/>`;
            const ctr = isS ? `<circle cx="50" cy="50" r="24" fill="#10b981"/><text x="50" y="60" text-anchor="middle" font-size="28">⚡</text>`
              : isT ? `<circle cx="50" cy="50" r="22" fill="${pow[r][c] ? '#06b6d4' : '#334155'}"/><text x="50" y="60" text-anchor="middle" font-size="26">💎</text>`
              : `<circle cx="50" cy="50" r="11" fill="${st}"/>`;
            el.innerHTML = `<svg class="pipe-svg" viewBox="0 0 100 100">${ln}${ctr}</svg>`;
            el.onclick = () => {
              cur[r][c] = rotM(m, 1); onMove(); audio.playRotate(); render();
              const np = calcPow();
              if (leaves.every(([tr, tc]) => np[tr][tc])) { audio.playConnect(); setTimeout(() => onWin(size * 3), 220); }
            };
          }
          board.appendChild(el);
        }
      }
    };
    render();
    return {
      reset: () => { cur = init.map((r) => r.slice()); render(); },
      hint: () => {
        for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) {
          if (cur[r][c] !== mask[r][c]) { cur[r][c] = mask[r][c]; render(); return; }
        }
      }
    };
  }

  // 13 & 14: rot_align & rot_gear
  if (mode === 'rot_align' || mode === 'rot_gear') {
    const arrows = ['⬆️', '➡️', '⬇️', '⬅️'];
    const grid = Array.from({ length: size }, () => Array(size).fill(0));
    for (let i = 0; i < 4 + tier; i++) {
      const r = Math.floor(rng() * size), c = Math.floor(rng() * size);
      grid[r][c] = (grid[r][c] + 3) % 4;
      if (mode === 'rot_gear' && c + 1 < size) grid[r][c + 1] = (grid[r][c + 1] + 3) % 4;
    }
    const init = grid.map((r) => r.slice());
    let cur = init.map((r) => r.slice());
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${size}, 1fr)`;
      for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) {
        const el = document.createElement('div');
        el.className = 'tile' + (cur[r][c] === 0 ? ' path-start' : '');
        el.textContent = mode === 'rot_gear' ? (cur[r][c] === 0 ? '🔓' : arrows[cur[r][c]]) : arrows[cur[r][c]];
        el.onclick = () => {
          cur[r][c] = (cur[r][c] + 1) % 4;
          if (mode === 'rot_gear' && c + 1 < size) cur[r][c + 1] = (cur[r][c + 1] + 1) % 4;
          onMove(); audio.playRotate(); render();
          if (cur.every((row) => row.every((v) => v === 0))) setTimeout(() => onWin(size * 3), 200);
        };
        board.appendChild(el);
      }
    };
    render();
    return { reset: () => { cur = init.map((r) => r.slice()); render(); }, hint: () => toast('সবগুলো উপরের দিকে (⬆️/🔓) আনুন!') };
  }

  // 15. rot_pattern (2x2 Quadrant Rotate)
  if (mode === 'rot_pattern') {
    const s = 4;
    const grid = Array.from({ length: s }, (_, r) => Array.from({ length: s }, () => (r < 2 ? 1 : 0)));
    const rotQ = (g, r, c) => {
      const t = g[r][c]; g[r][c] = g[r + 1][c]; g[r + 1][c] = g[r + 1][c + 1]; g[r + 1][c + 1] = g[r][c + 1]; g[r][c + 1] = t;
    };
    for (let i = 0; i < 4 + tier; i++) rotQ(grid, Math.floor(rng() * 3), Math.floor(rng() * 3));
    const init = grid.map((r) => r.slice());
    let cur = init.map((r) => r.slice());
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
      for (let r = 0; r < s; r++) for (let c = 0; c < s; c++) {
        const el = document.createElement('div');
        el.className = 'tile' + (cur[r][c] ? ' path-active' : '');
        el.textContent = cur[r][c] ? '💎' : '';
        el.onclick = () => {
          const qr = Math.min(s - 2, r), qc = Math.min(s - 2, c);
          rotQ(cur, qr, qc); onMove(); audio.playRotate(); render();
          if (cur.slice(0, 2).every((row) => row.every((v) => v === 1))) setTimeout(() => onWin(8), 200);
        };
        board.appendChild(el);
      }
    };
    render();
    return { reset: () => { cur = init.map((r) => r.slice()); render(); }, hint: () => toast('সব 💎 টাইল উপরের ২ সারিতে নিয়ে আসুন!') };
  }

  // 16 & 17: math_sumgrid & math_prodgrid
  if (mode === 'math_sumgrid' || mode === 'math_prodgrid') {
    const isProd = mode === 'math_prodgrid';
    const s = isProd ? 3 : size;
    const vals = Array.from({ length: s }, () => Array.from({ length: s }, () => (isProd ? 2 + Math.floor(rng() * 4) : 1 + Math.floor(rng() * (5 + tier)))));
    const sol = Array.from({ length: s }, () => Array.from({ length: s }, () => (rng() > 0.45 ? 1 : 0)));
    if (sol.every((r) => r.every((v) => v === 0))) sol[0][0] = 1;
    const rowT = vals.map((row, r) => row.reduce((a, v, c) => (sol[r][c] ? (isProd ? a * v : a + v) : a), isProd ? 1 : 0));
    const colT = Array.from({ length: s }, (_, c) => vals.reduce((a, row, r) => (sol[r][c] ? (isProd ? a * row[c] : a + row[c]) : a), isProd ? 1 : 0));
    let sel = Array.from({ length: s }, () => Array(s).fill(0));

    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s + 1}, 1fr)`;
      const cH = document.createElement('div'); cH.className = 'tile sum-header'; cH.textContent = isProd ? '∏' : '∑'; board.appendChild(cH);
      for (let c = 0; c < s; c++) {
        const curC = vals.reduce((a, row, r) => (sel[r][c] ? (isProd ? a * row[c] : a + row[c]) : a), isProd ? 1 : 0);
        const h = document.createElement('div'); h.className = 'tile sum-header' + (curC === colT[c] ? ' matched' : curC > colT[c] ? ' over' : '');
        h.textContent = colT[c]; board.appendChild(h);
      }
      for (let r = 0; r < s; r++) {
        const curR = vals[r].reduce((a, v, c) => (sel[r][c] ? (isProd ? a * v : a + v) : a), isProd ? 1 : 0);
        const rh = document.createElement('div'); rh.className = 'tile sum-header' + (curR === rowT[r] ? ' matched' : curR > rowT[r] ? ' over' : '');
        rh.textContent = rowT[r]; board.appendChild(rh);
        for (let c = 0; c < s; c++) {
          const el = document.createElement('div');
          el.className = 'tile' + (sel[r][c] ? ' sum-selected' : '');
          el.textContent = vals[r][c];
          el.onclick = () => {
            sel[r][c] = sel[r][c] ? 0 : 1; onMove(); audio.playTap(sel[r][c] ? 5 : 1); render();
            const rOk = rowT.every((t, ri) => vals[ri].reduce((a, v, ci) => (sel[ri][ci] ? (isProd ? a * v : a + v) : a), isProd ? 1 : 0) === t);
            const cOk = colT.every((t, ci) => vals.reduce((a, row, ri) => (sel[ri][ci] ? (isProd ? a * row[ci] : a + row[ci]) : a), isProd ? 1 : 0) === t);
            if (rOk && cOk) setTimeout(() => onWin(s * 2), 200);
          };
          board.appendChild(el);
        }
      }
    };
    render();
    return {
      reset: () => { sel = Array.from({ length: s }, () => Array(s).fill(0)); render(); },
      hint: () => {
        for (let r = 0; r < s; r++) for (let c = 0; c < s; c++) if (sel[r][c] !== sol[r][c]) { sel[r][c] = sol[r][c]; render(); return; }
      }
    };
  }

  // 18. math_latin (Mini Sudoku / Latin Square)
  if (mode === 'math_latin') {
    const s = tier < 4 ? 3 : 4;
    const base = Array.from({ length: s }, (_, r) => Array.from({ length: s }, (_, c) => ((r + c) % s) + 1));
    const fixed = Array.from({ length: s }, () => Array(s).fill(false));
    let cur = base.map((row, r) => row.map((v, c) => { if (rng() > 0.55) { fixed[r][c] = true; return v; } return 0; }));
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
      for (let r = 0; r < s; r++) for (let c = 0; c < s; c++) {
        const el = document.createElement('div');
        el.className = 'tile' + (fixed[r][c] ? ' path-start' : cur[r][c] ? ' sum-selected' : '');
        el.textContent = cur[r][c] || '';
        if (!fixed[r][c]) el.onclick = () => {
          cur[r][c] = (cur[r][c] % s) + 1; onMove(); audio.playTap(cur[r][c]); render();
          const ok = cur.every((row) => new Set(row).size === s && !row.includes(0)) &&
            Array.from({ length: s }, (_, ci) => new Set(cur.map((row) => row[ci])).size === s).every(Boolean);
          if (ok) setTimeout(() => onWin(s * 3), 200);
        };
        board.appendChild(el);
      }
    };
    render();
    return { reset: () => { cur = base.map((row, r) => row.map((v, c) => (fixed[r][c] ? v : 0))); render(); }, hint: () => toast('প্রতিটি সারি ও কলামে ১ থেকে ' + s + ' একবার করে বসান!') };
  }

  // 19 & 20: math_calc24 & math_balance
  const nums = Array.from({ length: 6 }, () => 2 + Math.floor(rng() * (10 + tier * 2)));
  const pickIdx = [0, 2, 4];
  const target = pickIdx.reduce((a, i) => a + nums[i], 0);
  let sel = new Set();
  const render = () => {
    const sum = [...sel].reduce((a, i) => a + nums[i], 0);
    board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(3, 1fr)';
    const hdr = document.createElement('div');
    hdr.style.cssText = 'grid-column:1/-1; text-align:center; padding:12px; background:var(--surface); border-radius:14px; font-size:18px; font-weight:800;';
    hdr.innerHTML = mode === 'math_balance'
      ? `⚖️ বাম: <b style="color:var(--warn)">${target} kg</b> &nbsp;|&nbsp; ডান: <b style="color:var(--accent)">${sum} kg</b>`
      : `🎯 টার্গেট: <b style="color:var(--accent-2)">${target}</b> &nbsp;|&nbsp; বর্তমান: <b style="color:var(--accent)">${sum}</b>`;
    board.appendChild(hdr);
    nums.forEach((n, i) => {
      const el = document.createElement('div');
      el.className = 'tile' + (sel.has(i) ? ' sum-selected' : '');
      el.textContent = mode === 'math_balance' ? `${n}kg` : n;
      el.onclick = () => {
        if (sel.has(i)) sel.delete(i); else sel.add(i);
        onMove(); audio.playTap(sel.size); render();
        const ns = [...sel].reduce((a, k) => a + nums[k], 0);
        if (ns === target) setTimeout(() => onWin(4), 200);
      };
      board.appendChild(el);
    });
  };
  render();
  return { reset: () => { sel.clear(); render(); }, hint: () => { sel.add(pickIdx[0]); render(); } };
}
