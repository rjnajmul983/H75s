import { TOTAL_LEVELS, CHAPTERS, MODE_INFO, RANKS, THEMES, getLevelMeta } from './config.js';
import { AudioEngine } from './audio.js';
import { generateLevel } from './generator.js';

// Splash dismiss
setTimeout(() => {
  const sp = document.getElementById('splash-screen');
  if (sp) { sp.style.opacity = '0'; setTimeout(() => sp.remove(), 450); }
}, 1150);

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}

const audio = new AudioEngine();

// Persistent Profile
const defaultProfile = {
  unlockedLevel: 1,
  stars: {}, // { levelNum: 1..3 }
  hints: 5,
  iq: 90,
  theme: 'cyber',
  sound: true,
  vibrate: true,
  lastPlayDate: '',
  streak: 1,
  dailyDoneDate: ''
};

let profile = Object.assign({}, defaultProfile, JSON.parse(localStorage.getItem('neurogrid_iq_profile_v1') || '{}'));

function updateStreak() {
  const today = new Date().toISOString().slice(0, 10);
  if (profile.lastPlayDate !== today) {
    if (profile.lastPlayDate) {
      const diff = (new Date(today) - new Date(profile.lastPlayDate)) / 86400000;
      profile.streak = diff <= 1.5 ? profile.streak + 1 : 1;
    }
    profile.lastPlayDate = today;
    saveProfile();
  }
}

function saveProfile() {
  localStorage.setItem('neurogrid_iq_profile_v1', JSON.stringify(profile));
  document.body.dataset.theme = profile.theme;
  audio.muted = !profile.sound;
  audio.vibrateEnabled = profile.vibrate;
}

// Screens & Elements
const scrHome = document.getElementById('screen-home');
const scrChapters = document.getElementById('screen-chapters');
const scrGame = document.getElementById('screen-game');
const modalWin = document.getElementById('modal-win');
const modalSettings = document.getElementById('modal-settings');
const elBoard = document.getElementById('puzzle-board');
const elToast = document.getElementById('toast');

function showScreen(target) {
  [scrHome, scrChapters, scrGame].forEach((s) => s.classList.add('hidden'));
  target.classList.remove('hidden');
}

function showToast(msg) {
  elToast.textContent = msg;
  elToast.classList.remove('hidden');
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => elToast.classList.add('hidden'), 2400);
}

function getRank(iq) {
  let r = RANKS[0];
  for (const item of RANKS) if (iq >= item.minIq) r = item;
  return r;
}

function refreshHome() {
  const solvedCount = Object.keys(profile.stars).length;
  const totalStars = Object.values(profile.stars).reduce((a, b) => a + b, 0);
  const rank = getRank(profile.iq);
  const nextLvl = Math.min(TOTAL_LEVELS, profile.unlockedLevel);
  const meta = getLevelMeta(nextLvl);

  document.getElementById('home-rank').textContent = `${rank.icon} ${rank.title}`;
  document.getElementById('home-iq').textContent = Math.round(profile.iq);
  document.getElementById('home-solved').textContent = solvedCount;
  document.getElementById('home-stars').textContent = totalStars;
  document.getElementById('home-streak').textContent = profile.streak;
  document.getElementById('home-hints').textContent = profile.hints;
  document.getElementById('home-next-level').textContent = nextLvl;
  document.getElementById('home-next-mode').textContent = `${MODE_INFO[meta.mode].nameBn} • ${meta.chapter.nameBn}`;
}

// Chapters & 500 Levels Map
let activeChapterIdx = 0;

function renderChapters() {
  const totalStars = Object.values(profile.stars).reduce((a, b) => a + b, 0);
  document.getElementById('chapters-stars').textContent = totalStars;

  const tabsEl = document.getElementById('chapter-tabs');
  tabsEl.innerHTML = '';
  CHAPTERS.forEach((ch, idx) => {
    const btn = document.createElement('button');
    btn.className = 'chapter-tab' + (idx === activeChapterIdx ? ' active' : '');
    btn.textContent = `${ch.badge} অধ্যায় ${ch.id}`;
    btn.onclick = () => { activeChapterIdx = idx; renderChapters(); };
    tabsEl.appendChild(btn);
  });

  const ch = CHAPTERS[activeChapterIdx];
  document.getElementById('chapter-banner').innerHTML = `
    <div><b>${ch.badge} ${ch.nameBn}</b><div style="font-size:11px;color:var(--muted)">${ch.subtitle}</div></div>
    <span style="font-size:12px;color:var(--accent);font-weight:700">লেভেল ${ch.range[0]}–${ch.range[1]}</span>
  `;

  const gridEl = document.getElementById('level-grid');
  gridEl.innerHTML = '';
  for (let lvl = ch.range[0]; lvl <= ch.range[1]; lvl++) {
    const unlocked = lvl <= profile.unlockedLevel;
    const st = profile.stars[lvl] || 0;
    const btn = document.createElement('button');
    btn.className = 'lvl-btn' + (!unlocked ? ' locked' : '') + (lvl === profile.unlockedLevel ? ' current' : '') + (st > 0 ? ' solved' : '');
    btn.innerHTML = `
      <span class="l-num">${unlocked ? lvl : '🔒'}</span>
      <span class="l-stars">${st > 0 ? '⭐'.repeat(st) : ''}</span>
    `;
    if (unlocked) btn.onclick = () => startLevel(lvl, false);
    gridEl.appendChild(btn);
  }
}

// ---------------- GAMEPLAY STATE ----------------
let currentPuzzle = null;
let isDailyMode = false;
let moves = 0;
let startTime = 0;
let undoStack = [];
let hintCell = null;

// Mode-specific runtime states
let pathTrail = [];
let isDraggingPath = false;
let lightsGrid = [];
let pipesMasks = [];
let sumSelected = [];
let memPhase = 'preview'; // 'preview' | 'input'
let memPicked = [];

function startLevel(levelNum, daily = false) {
  isDailyMode = daily;
  currentPuzzle = generateLevel(levelNum);
  moves = 0;
  startTime = Date.now();
  undoStack = [];
  hintCell = null;

  const info = MODE_INFO[currentPuzzle.mode];
  document.getElementById('game-level-title').textContent = daily ? '⚡ ডেইলি আইকিউ টেস্ট' : `লেভেল ${levelNum}`;
  document.getElementById('game-mode-badge').textContent = `${info.icon} ${info.nameBn}`;
  document.getElementById('game-instruction').textContent = currentPuzzle.mode === 'lights' && currentPuzzle.useDiagonal
    ? 'বিশেষ নিয়ম (X-ফ্লিপ): ট্যাপ করলে কোণাকুণি ঘরগুলোর আলো বদলে যাবে! সব আলো জ্বালান।'
    : currentPuzzle.mode === 'memory' && currentPuzzle.ordered
      ? 'সংখ্যাগুলোর ক্রম (১, ২, ৩...) মনে রাখুন এবং ঠিক সেই ক্রমে ট্যাপ করুন!'
      : info.hintBn;
  document.getElementById('game-moves').textContent = '0';
  document.getElementById('game-hints').textContent = profile.hints;

  // Initialize mode state
  if (currentPuzzle.mode === 'path') {
    pathTrail = [currentPuzzle.start.slice()];
  } else if (currentPuzzle.mode === 'lights') {
    lightsGrid = currentPuzzle.grid.map((r) => r.slice());
  } else if (currentPuzzle.mode === 'pipes') {
    pipesMasks = currentPuzzle.currentMasks.map((r) => r.slice());
  } else if (currentPuzzle.mode === 'sumgrid') {
    sumSelected = Array.from({ length: currentPuzzle.size }, () => Array(currentPuzzle.size).fill(0));
  } else if (currentPuzzle.mode === 'memory') {
    memPhase = 'preview';
    memPicked = [];
  }

  modalWin.classList.add('hidden');
  showScreen(scrGame);
  renderBoard();

  if (currentPuzzle.mode === 'memory') {
    clearTimeout(startLevel._memTimer);
    startLevel._memTimer = setTimeout(() => {
      if (currentPuzzle && currentPuzzle.mode === 'memory') {
        memPhase = 'input';
        renderBoard();
        showToast('এবার মনে করে ট্যাপ করুন!');
      }
    }, currentPuzzle.previewMs);
  }
}

function recordMove() {
  moves++;
  document.getElementById('game-moves').textContent = moves;
}

function onLevelWon() {
  audio.playWin();
  const elapsedSec = Math.max(1, Math.round((Date.now() - startTime) / 1000));
  const par = currentPuzzle.parMoves || 5;
  const stars = moves <= par + 2 ? 3 : moves <= par + 6 ? 2 : 1;

  if (isDailyMode) {
    const today = new Date().toISOString().slice(0, 10);
    if (profile.dailyDoneDate !== today) {
      profile.dailyDoneDate = today;
      profile.hints += 2;
      profile.iq = Math.min(185, profile.iq + 1.5);
    }
  } else {
    const lvl = currentPuzzle.level;
    const prevStars = profile.stars[lvl] || 0;
    if (stars > prevStars) {
      profile.stars[lvl] = stars;
      profile.iq = Math.min(185, profile.iq + (prevStars === 0 ? 0.45 : 0.15));
    }
    if (lvl >= profile.unlockedLevel && lvl < TOTAL_LEVELS) {
      profile.unlockedLevel = lvl + 1;
    }
    if (lvl % 5 === 0 && prevStars === 0) {
      profile.hints += 1; // Bonus hint every 5 new levels!
    }
  }
  saveProfile();

  document.getElementById('win-stars').textContent = '⭐'.repeat(stars) + '☆'.repeat(3 - stars);
  document.getElementById('win-title').textContent = isDailyMode ? 'ডেইলি চ্যালেঞ্জ সম্পন্ন! (+2 💡)' : `লেভেল ${currentPuzzle.level} সম্পন্ন!`;
  document.getElementById('win-moves').textContent = moves;
  document.getElementById('win-time').textContent = `${elapsedSec}s`;
  document.getElementById('win-iq').textContent = Math.round(profile.iq);
  document.getElementById('btn-win-next').classList.toggle('hidden', isDailyMode || currentPuzzle.level >= TOTAL_LEVELS);
  modalWin.classList.remove('hidden');
}

// ---------------- BOARD RENDERING & LOGIC ----------------
function renderBoard() {
  const p = currentPuzzle;
  elBoard.innerHTML = '';

  if (p.mode === 'path') renderPathBoard(p);
  else if (p.mode === 'lights') renderLightsBoard(p);
  else if (p.mode === 'pipes') renderPipesBoard(p);
  else if (p.mode === 'sumgrid') renderSumGridBoard(p);
  else if (p.mode === 'memory') renderMemoryBoard(p);
}

// MODE 1: ONE-LINE PATH
function renderPathBoard(p) {
  elBoard.style.gridTemplateColumns = `repeat(${p.size}, 1fr)`;
  const trailMap = new Map(pathTrail.map(([r, c], idx) => [`${r},${c}`, idx]));
  const head = pathTrail[pathTrail.length - 1];

  for (let r = 0; r < p.size; r++) {
    for (let c = 0; c < p.size; c++) {
      const tile = document.createElement('div');
      tile.className = 'tile';
      tile.dataset.r = r;
      tile.dataset.c = c;

      if (p.grid[r][c] === 0) {
        tile.classList.add('wall');
      } else {
        const key = `${r},${c}`;
        const idx = trailMap.get(key);
        if (r === p.start[0] && c === p.start[1]) tile.classList.add('path-start');
        if (idx !== undefined) {
          tile.classList.add(head[0] === r && head[1] === c ? 'path-head' : 'path-active');
          tile.textContent = idx === 0 ? '▶' : idx + 1;
        }
        if (hintCell && hintCell[0] === r && hintCell[1] === c) tile.classList.add('hint-glow');

        tile.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          isDraggingPath = true;
          handlePathStep(r, c);
        });
      }
      elBoard.appendChild(tile);
    }
  }
}

elBoard.addEventListener('pointermove', (e) => {
  if (!isDraggingPath || !currentPuzzle || currentPuzzle.mode !== 'path') return;
  const el = document.elementFromPoint(e.clientX, e.clientY);
  if (el && el.dataset && el.dataset.r !== undefined) {
    handlePathStep(Number(el.dataset.r), Number(el.dataset.c));
  }
});
window.addEventListener('pointerup', () => (isDraggingPath = false));

function handlePathStep(r, c) {
  const p = currentPuzzle;
  if (p.grid[r][c] === 0) return;
  const head = pathTrail[pathTrail.length - 1];
  if (head[0] === r && head[1] === c) return;

  // Backtrack one step if tapping previous cell
  if (pathTrail.length >= 2) {
    const prev = pathTrail[pathTrail.length - 2];
    if (prev[0] === r && prev[1] === c) {
      pathTrail.pop();
      audio.playTap(-2);
      renderBoard();
      return;
    }
  }

  // Must be orthogonally adjacent & not already visited
  const isAdj = Math.abs(head[0] - r) + Math.abs(head[1] - c) === 1;
  const already = pathTrail.some(([pr, pc]) => pr === r && pc === c);
  if (isAdj && !already) {
    undoStack.push(pathTrail.map((x) => x.slice()));
    pathTrail.push([r, c]);
    hintCell = null;
    recordMove();
    audio.playTap(pathTrail.length);
    renderBoard();

    if (pathTrail.length === p.solution.length) {
      setTimeout(onLevelWon, 200);
    }
  }
}

// MODE 2: QUANTUM FLIP (LIGHTS OUT)
function renderLightsBoard(p) {
  elBoard.style.gridTemplateColumns = `repeat(${p.size}, 1fr)`;
  for (let r = 0; r < p.size; r++) {
    for (let c = 0; c < p.size; c++) {
      const tile = document.createElement('div');
      const on = lightsGrid[r][c] === 1;
      tile.className = 'tile ' + (on ? 'light-on' : 'light-off');
      tile.textContent = on ? '💡' : '○';
      if (hintCell && hintCell[0] === r && hintCell[1] === c) tile.classList.add('hint-glow');
      tile.onclick = () => {
        undoStack.push(lightsGrid.map((row) => row.slice()));
        const offsets = p.useDiagonal
          ? [[0, 0], [-1, -1], [-1, 1], [1, -1], [1, 1]]
          : [[0, 0], [-1, 0], [1, 0], [0, -1], [0, 1]];
        for (const [dr, dc] of offsets) {
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < p.size && nc >= 0 && nc < p.size) {
            lightsGrid[nr][nc] = lightsGrid[nr][nc] ? 0 : 1;
          }
        }
        hintCell = null;
        recordMove();
        audio.playTap(on ? 0 : 4);
        renderBoard();
        if (lightsGrid.every((row) => row.every((v) => v === 1))) {
          setTimeout(onLevelWon, 220);
        }
      };
      elBoard.appendChild(tile);
    }
  }
}

// MODE 3: CIRCUIT ROTATE (PIPES)
function computePoweredPipes(p) {
  const powered = Array.from({ length: p.size }, () => Array(p.size).fill(false));
  const [sr, sc] = p.source;
  const q = [[sr, sc]];
  powered[sr][sc] = true;
  const dirs = [[-1, 0, 1, 4], [0, 1, 2, 8], [1, 0, 4, 1], [0, -1, 8, 2]];

  while (q.length > 0) {
    const [r, c] = q.shift();
    const m = pipesMasks[r][c];
    for (const [dr, dc, myBit, oppBit] of dirs) {
      if (!(m & myBit)) continue;
      const nr = r + dr, nc = c + dc;
      if (nr >= 0 && nr < p.size && nc >= 0 && nc < p.size && !powered[nr][nc]) {
        if (pipesMasks[nr][nc] & oppBit) {
          powered[nr][nc] = true;
          q.push([nr, nc]);
        }
      }
    }
  }
  return powered;
}

function pipeSvgMarkup(mask, isPowered, isSource, isTarget) {
  const stroke = isPowered ? '#06b6d4' : '#64748b';
  let lines = '';
  if (mask & 1) lines += `<line x1="50" y1="50" x2="50" y2="0" stroke="${stroke}" stroke-width="18" stroke-linecap="round"/>`;
  if (mask & 2) lines += `<line x1="50" y1="50" x2="100" y2="50" stroke="${stroke}" stroke-width="18" stroke-linecap="round"/>`;
  if (mask & 4) lines += `<line x1="50" y1="50" x2="50" y2="100" stroke="${stroke}" stroke-width="18" stroke-linecap="round"/>`;
  if (mask & 8) lines += `<line x1="50" y1="50" x2="0" y2="50" stroke="${stroke}" stroke-width="18" stroke-linecap="round"/>`;

  let center = `<circle cx="50" cy="50" r="11" fill="${stroke}"/>`;
  if (isSource) center = `<circle cx="50" cy="50" r="24" fill="#10b981"/><text x="50" y="60" text-anchor="middle" font-size="28">⚡</text>`;
  else if (isTarget) center = `<circle cx="50" cy="50" r="22" fill="${isPowered ? '#06b6d4' : '#334155'}"/><text x="50" y="60" text-anchor="middle" font-size="26">💎</text>`;

  return `<svg class="pipe-svg" viewBox="0 0 100 100">${lines}${center}</svg>`;
}

function renderPipesBoard(p) {
  elBoard.style.gridTemplateColumns = `repeat(${p.size}, 1fr)`;
  const powered = computePoweredPipes(p);

  for (let r = 0; r < p.size; r++) {
    for (let c = 0; c < p.size; c++) {
      const m = pipesMasks[r][c];
      const tile = document.createElement('div');
      tile.className = 'tile pipe-tile';
      if (m === 0) {
        tile.classList.add('wall');
      } else {
        const isSource = r === p.source[0] && c === p.source[1];
        const isTarget = p.targets.some(([tr, tc]) => tr === r && tc === c);
        if (powered[r][c]) tile.classList.add('pipe-powered');
        if (hintCell && hintCell[0] === r && hintCell[1] === c) tile.classList.add('hint-glow');
        tile.innerHTML = pipeSvgMarkup(m, powered[r][c], isSource, isTarget);

        tile.onclick = () => {
          undoStack.push(pipesMasks.map((row) => row.slice()));
          let next = 0;
          if (m & 1) next |= 2;
          if (m & 2) next |= 4;
          if (m & 4) next |= 8;
          if (m & 8) next |= 1;
          pipesMasks[r][c] = next;
          hintCell = null;
          recordMove();
          audio.playRotate();
          renderBoard();

          const newPow = computePoweredPipes(p);
          const allLit = p.targets.every(([tr, tc]) => newPow[tr][tc]);
          if (allLit) {
            audio.playConnect();
            setTimeout(onLevelWon, 240);
          }
        };
      }
      elBoard.appendChild(tile);
    }
  }
}

// MODE 4: SUM MATRIX
function renderSumGridBoard(p) {
  elBoard.style.gridTemplateColumns = `repeat(${p.size + 1}, 1fr)`;

  const curRowSums = Array.from({ length: p.size }, (_, r) =>
    p.values[r].reduce((acc, v, c) => acc + (sumSelected[r][c] ? v : 0), 0)
  );
  const curColSums = Array.from({ length: p.size }, (_, c) =>
    p.values.reduce((acc, row, r) => acc + (sumSelected[r][c] ? row[c] : 0), 0)
  );

  // Top-left corner empty + Column Target Headers
  const corner = document.createElement('div');
  corner.className = 'tile sum-header';
  corner.textContent = '∑';
  elBoard.appendChild(corner);

  for (let c = 0; c < p.size; c++) {
    const hdr = document.createElement('div');
    const diff = curColSums[c] - p.colTargets[c];
    hdr.className = 'tile sum-header' + (diff === 0 ? ' matched' : diff > 0 ? ' over' : '');
    hdr.textContent = p.colTargets[c];
    elBoard.appendChild(hdr);
  }

  // Rows
  for (let r = 0; r < p.size; r++) {
    const rhdr = document.createElement('div');
    const rdiff = curRowSums[r] - p.rowTargets[r];
    rhdr.className = 'tile sum-header' + (rdiff === 0 ? ' matched' : rdiff > 0 ? ' over' : '');
    rhdr.textContent = p.rowTargets[r];
    elBoard.appendChild(rhdr);

    for (let c = 0; c < p.size; c++) {
      const tile = document.createElement('div');
      tile.className = 'tile' + (sumSelected[r][c] ? ' sum-selected' : '');
      tile.textContent = p.values[r][c];
      if (hintCell && hintCell[0] === r && hintCell[1] === c) tile.classList.add('hint-glow');
      tile.onclick = () => {
        undoStack.push(sumSelected.map((row) => row.slice()));
        sumSelected[r][c] = sumSelected[r][c] ? 0 : 1;
        hintCell = null;
        recordMove();
        audio.playTap(sumSelected[r][c] ? 5 : 1);
        renderBoard();

        const rowsOk = p.rowTargets.every((t, ri) =>
          p.values[ri].reduce((a, v, ci) => a + (sumSelected[ri][ci] ? v : 0), 0) === t
        );
        const colsOk = p.colTargets.every((t, ci) =>
          p.values.reduce((a, row, ri) => a + (sumSelected[ri][ci] ? row[ci] : 0), 0) === t
        );
        if (rowsOk && colsOk) setTimeout(onLevelWon, 220);
      };
      elBoard.appendChild(tile);
    }
  }
}

// MODE 5: MEMORY MATRIX
function renderMemoryBoard(p) {
  elBoard.style.gridTemplateColumns = `repeat(${p.size}, 1fr)`;
  const seqMap = new Map(p.sequence.map(([r, c], idx) => [`${r},${c}`, idx]));
  const pickedSet = new Set(memPicked.map(([r, c]) => `${r},${c}`));

  for (let r = 0; r < p.size; r++) {
    for (let c = 0; c < p.size; c++) {
      const key = `${r},${c}`;
      const tile = document.createElement('div');
      tile.className = 'tile';

      if (memPhase === 'preview') {
        if (seqMap.has(key)) {
          tile.classList.add('mem-flash');
          tile.textContent = p.ordered ? seqMap.get(key) + 1 : '✦';
        }
      } else {
        if (pickedSet.has(key)) {
          tile.classList.add('mem-correct');
          tile.textContent = p.ordered ? seqMap.get(key) + 1 : '✓';
        }
        if (hintCell && hintCell[0] === r && hintCell[1] === c) tile.classList.add('hint-glow');

        tile.onclick = () => {
          if (pickedSet.has(key)) return;
          recordMove();
          const expectedIdx = memPicked.length;
          const isValid = p.ordered
            ? seqMap.get(key) === expectedIdx
            : seqMap.has(key);

          if (isValid) {
            memPicked.push([r, c]);
            hintCell = null;
            audio.playTap(memPicked.length * 2);
            renderBoard();
            if (memPicked.length === p.sequence.length) {
              setTimeout(onLevelWon, 220);
            }
          } else {
            tile.classList.add('mem-wrong');
            tile.textContent = '✕';
            audio.playError();
            showToast('ভুল ঘর! নকশাটি আবার দেখানো হচ্ছে...');
            setTimeout(() => startLevel(p.level, isDailyMode), 650);
          }
        };
      }
      elBoard.appendChild(tile);
    }
  }
}

// ---------------- CONTROLS: UNDO, RESET, HINT ----------------
document.getElementById('btn-undo').onclick = () => {
  if (!undoStack.length) { showToast('আন্ডু করার মতো চাল নেই'); return; }
  const prev = undoStack.pop();
  if (currentPuzzle.mode === 'path') pathTrail = prev;
  else if (currentPuzzle.mode === 'lights') lightsGrid = prev;
  else if (currentPuzzle.mode === 'pipes') pipesMasks = prev;
  else if (currentPuzzle.mode === 'sumgrid') sumSelected = prev;
  audio.playTap(-1);
  renderBoard();
};

document.getElementById('btn-reset').onclick = () => {
  audio.playTap(0);
  startLevel(currentPuzzle.level, isDailyMode);
};

document.getElementById('btn-hint').onclick = () => {
  if (profile.hints <= 0) {
    showToast('হিন্ট শেষ! ডেইলি আইকিউ টেস্ট খেলে +2 হিন্ট পান।');
    return;
  }
  const p = currentPuzzle;
  let target = null;

  if (p.mode === 'path') {
    // Find next cell along the true solution from current prefix
    let matchLen = 0;
    for (let i = 0; i < pathTrail.length && i < p.solution.length; i++) {
      if (pathTrail[i][0] === p.solution[i][0] && pathTrail[i][1] === p.solution[i][1]) matchLen++;
      else break;
    }
    if (matchLen < pathTrail.length) {
      pathTrail = pathTrail.slice(0, Math.max(1, matchLen));
    }
    target = p.solution[Math.min(p.solution.length - 1, pathTrail.length)];
  } else if (p.mode === 'lights') {
    target = p.solution[0];
  } else if (p.mode === 'pipes') {
    for (let r = 0; r < p.size && !target; r++) {
      for (let c = 0; c < p.size && !target; c++) {
        if (pipesMasks[r][c] !== p.targetMasks[r][c]) {
          pipesMasks[r][c] = p.targetMasks[r][c]; // Auto-align 1 pipe!
          target = [r, c];
        }
      }
    }
  } else if (p.mode === 'sumgrid') {
    for (let r = 0; r < p.size && !target; r++) {
      for (let c = 0; c < p.size && !target; c++) {
        if (sumSelected[r][c] !== p.solution[r][c]) target = [r, c];
      }
    }
  } else if (p.mode === 'memory') {
    const pickedSet = new Set(memPicked.map(([r, c]) => `${r},${c}`));
    target = p.sequence.find(([r, c]) => !pickedSet.has(`${r},${c}`));
  }

  if (target) {
    profile.hints--;
    saveProfile();
    document.getElementById('game-hints').textContent = profile.hints;
    hintCell = target;
    audio.playHint();
    renderBoard();
    showToast('💡 সঠিক ঘরটি হাইলাইট করা হয়েছে!');
  }
};

// ---------------- NAVIGATION & SETTINGS ----------------
document.getElementById('btn-play-current').onclick = () => startLevel(Math.min(TOTAL_LEVELS, profile.unlockedLevel), false);
document.getElementById('btn-open-chapters').onclick = () => {
  activeChapterIdx = Math.min(CHAPTERS.length - 1, Math.floor((profile.unlockedLevel - 1) / 50));
  renderChapters();
  showScreen(scrChapters);
};
document.getElementById('btn-daily-brain').onclick = () => {
  const dayNum = Math.floor(Date.now() / 86400000);
  const dailyLvl = 120 + (dayNum % 350);
  startLevel(dailyLvl, true);
};
document.getElementById('btn-back-home-chapters').onclick = () => { refreshHome(); showScreen(scrHome); };
document.getElementById('btn-back-from-game').onclick = () => { refreshHome(); showScreen(scrHome); };

document.getElementById('btn-win-replay').onclick = () => startLevel(currentPuzzle.level, isDailyMode);
document.getElementById('btn-win-next').onclick = () => startLevel(Math.min(TOTAL_LEVELS, currentPuzzle.level + 1), false);

// Settings Modal
function renderThemes() {
  const el = document.getElementById('theme-list');
  el.innerHTML = '';
  THEMES.forEach((t) => {
    const btn = document.createElement('button');
    btn.className = 'theme-btn' + (profile.theme === t.id ? ' active' : '');
    btn.innerHTML = `<span class="theme-dot" style="background:${t.preview}"></span><span>${t.name}</span>`;
    btn.onclick = () => { profile.theme = t.id; saveProfile(); renderThemes(); };
    el.appendChild(btn);
  });
}

document.getElementById('btn-open-settings').onclick = () => {
  document.getElementById('toggle-sound').checked = profile.sound;
  document.getElementById('toggle-vibrate').checked = profile.vibrate;
  renderThemes();
  modalSettings.classList.remove('hidden');
};
document.getElementById('btn-close-settings').onclick = () => modalSettings.classList.add('hidden');
document.getElementById('toggle-sound').onchange = (e) => { profile.sound = e.target.checked; saveProfile(); };
document.getElementById('toggle-vibrate').onchange = (e) => { profile.vibrate = e.target.checked; saveProfile(); };
document.getElementById('btn-reset-progress').onclick = () => {
  if (confirm('আপনার সব প্রগ্রেস ও IQ স্কোর মুছে ফেলতে চান?')) {
    profile = Object.assign({}, defaultProfile);
    saveProfile();
    refreshHome();
    modalSettings.classList.add('hidden');
  }
};

// Boot
updateStreak();
saveProfile();
refreshHome();
showScreen(scrHome);
