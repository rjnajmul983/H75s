import { TOTAL_LEVELS, CHAPTERS, MODES, RANKS, THEMES, createRng, getLevelMeta } from './config.js';
import { AudioEngine } from './audio.js';
import { mountGroupA } from './modes/groupA.js';
import { mountGroupB } from './modes/groupB.js';
import { mountGroupC } from './modes/groupC.js';
import { mountGroupD } from './modes/groupD.js';
import { mountGroupE } from './modes/groupE.js';

setTimeout(() => {
  const sp = document.getElementById('splash-screen');
  if (sp) { sp.style.opacity = '0'; setTimeout(() => sp.remove(), 450); }
}, 1100);

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}

const audio = new AudioEngine();
const defaultProfile = {
  unlockedLevel: 1, stars: {}, hints: 8, iq: 90,
  theme: 'cyber', sound: true, vibrate: true,
  lastPlayDate: '', streak: 1, dailyDoneDate: ''
};
let profile = Object.assign({}, defaultProfile, JSON.parse(localStorage.getItem('mogojastro_50_profile') || '{}'));

function saveProfile() {
  localStorage.setItem('mogojastro_50_profile', JSON.stringify(profile));
  document.body.dataset.theme = profile.theme;
  audio.muted = !profile.sound;
  audio.vibrateEnabled = profile.vibrate;
}

const scrHome = document.getElementById('screen-home');
const scrChapters = document.getElementById('screen-chapters');
const scrGame = document.getElementById('screen-game');
const modalWin = document.getElementById('modal-win');
const modalSettings = document.getElementById('modal-settings');
const modalModes = document.getElementById('modal-modes');
const elBoard = document.getElementById('puzzle-board');
const elToast = document.getElementById('toast');

function showScreen(target) {
  [scrHome, scrChapters, scrGame].forEach((s) => s.classList.add('hidden'));
  target.classList.remove('hidden');
}

function showToast(msg) {
  elToast.textContent = msg;
  elToast.classList.remove('hidden');
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => elToast.classList.add('hidden'), 2400);
}

function getRank(iq) {
  let r = RANKS[0];
  for (const item of RANKS) if (iq >= item.minIq) r = item;
  return r;
}

function refreshHome() {
  const solvedCount = Object.keys(profile.stars).length;
  const totalStars = Object.values(profile.stars).reduce((a, b) => a + b, 0);
  const rank = getRank(profile.iq);
  const nextLvl = Math.min(TOTAL_LEVELS, profile.unlockedLevel);
  const meta = getLevelMeta(nextLvl);

  document.getElementById('home-rank').textContent = `${rank.icon} ${rank.title}`;
  document.getElementById('home-iq').textContent = Math.round(profile.iq);
  document.getElementById('home-solved').textContent = solvedCount;
  document.getElementById('home-stars').textContent = totalStars;
  document.getElementById('home-streak').textContent = profile.streak;
  document.getElementById('home-hints').textContent = profile.hints;
  document.getElementById('home-next-level').textContent = nextLvl;
  document.getElementById('home-next-mode').textContent = `${meta.modeObj.icon} ${meta.modeObj.nameBn} • ${meta.chapter.nameBn}`;
}

// Chapters & 500 Levels
let activeChapterIdx = 0;
function renderChapters() {
  document.getElementById('chapters-stars').textContent = Object.values(profile.stars).reduce((a, b) => a + b, 0);
  const tabsEl = document.getElementById('chapter-tabs');
  tabsEl.innerHTML = '';
  CHAPTERS.forEach((ch, idx) => {
    const btn = document.createElement('button');
    btn.className = 'chapter-tab' + (idx === activeChapterIdx ? ' active' : '');
    btn.textContent = `${ch.badge} অধ্যায় ${ch.id}`;
    btn.onclick = () => { activeChapterIdx = idx; renderChapters(); };
    tabsEl.appendChild(btn);
  });
  const ch = CHAPTERS[activeChapterIdx];
  document.getElementById('chapter-banner').innerHTML = `
    <div><b>${ch.badge} ${ch.nameBn}</b><div style="font-size:11px;color:var(--muted)">${ch.subtitle}</div></div>
    <span style="font-size:12px;color:var(--accent);font-weight:700">লেভেল ${ch.range[0]}–${ch.range[1]}</span>
  `;
  const gridEl = document.getElementById('level-grid');
  gridEl.innerHTML = '';
  for (let lvl = ch.range[0]; lvl <= ch.range[1]; lvl++) {
    const unlocked = lvl <= profile.unlockedLevel;
    const st = profile.stars[lvl] || 0;
    const meta = getLevelMeta(lvl);
    const btn = document.createElement('button');
    btn.className = 'lvl-btn' + (!unlocked ? ' locked' : '') + (lvl === profile.unlockedLevel ? ' current' : '') + (st > 0 ? ' solved' : '');
    btn.innerHTML = `<span class="l-num">${unlocked ? lvl : '🔒'}</span><span class="l-stars">${st > 0 ? '⭐'.repeat(st) : (unlocked ? meta.modeObj.icon : '')}</span>`;
    if (unlocked) btn.onclick = () => startLevel(lvl, false);
    gridEl.appendChild(btn);
  }
}

// 50 Modes Quick-Play Gallery
function renderModesGallery() {
  const list = document.getElementById('modes-gallery-list');
  list.innerHTML = '';
  MODES.forEach((m, idx) => {
    const b = document.createElement('button');
    b.className = 'mode-gallery-item';
    b.innerHTML = `<span class="mg-num">#${idx + 1}</span><span class="mg-icon">${m.icon}</span><span class="mg-name">${m.nameBn}</span>`;
    b.onclick = () => { modalModes.classList.add('hidden'); startLevel(idx + 1, false); };
    list.appendChild(b);
  });
}

// Gameplay Controller
const GROUP_A = new Set(['path_classic','path_checkpoint','path_ice','path_knight','path_maze','flip_plus','flip_cross','flip_rowcol','flip_tricolor','flip_mirror']);
const GROUP_B = new Set(['pipe_circuit','pipe_dual','rot_align','rot_gear','rot_pattern','math_sumgrid','math_prodgrid','math_latin','math_calc24','math_balance']);
const GROUP_C = new Set(['slide_15','slide_color','slide_swap','slide_tower','slide_water','mem_pattern','mem_order','mem_reverse','mem_pairs','mem_simon']);
const GROUP_D = new Set(['vis_odd','vis_color','vis_stroop','vis_count','vis_shadow','seq_number','seq_symbol','seq_mastermind','seq_binary','seq_cipher']);

let activeMeta = null;
let activeController = null;
let isDaily = false;
let moves = 0;
let startTime = 0;

function startLevel(levelNum, daily = false) {
  isDaily = daily;
  activeMeta = getLevelMeta(levelNum);
  moves = 0;
  startTime = Date.now();

  document.getElementById('game-level-title').textContent = daily ? '⚡ ডেইলি আইকিউ টেস্ট' : `লেভেল ${levelNum}`;
  document.getElementById('game-mode-badge').textContent = `${activeMeta.modeObj.icon} ${activeMeta.modeObj.nameBn}`;
  document.getElementById('game-instruction').textContent = activeMeta.modeObj.hintBn;
  document.getElementById('game-moves').textContent = '0';
  document.getElementById('game-hints').textContent = profile.hints;

  const ctx = {
    board: elBoard,
    rng: createRng(levelNum * 2654435761 + 1013904223),
    tier: activeMeta.tier,
    audio,
    toast: showToast,
    onMove: () => { moves++; document.getElementById('game-moves').textContent = moves; },
    onWin: (par) => handleWin(par)
  };

  elBoard.onpointermove = null;
  if (GROUP_A.has(activeMeta.mode)) activeController = mountGroupA(activeMeta.mode, ctx);
  else if (GROUP_B.has(activeMeta.mode)) activeController = mountGroupB(activeMeta.mode, ctx);
  else if (GROUP_C.has(activeMeta.mode)) activeController = mountGroupC(activeMeta.mode, ctx);
  else if (GROUP_D.has(activeMeta.mode)) activeController = mountGroupD(activeMeta.mode, ctx);
  else activeController = mountGroupE(activeMeta.mode, ctx);

  modalWin.classList.add('hidden');
  showScreen(scrGame);
}

function handleWin(par = 6) {
  audio.playWin();
  const elapsed = Math.max(1, Math.round((Date.now() - startTime) / 1000));
  const stars = moves <= par + 3 ? 3 : moves <= par + 8 ? 2 : 1;

  if (isDaily) {
    const today = new Date().toISOString().slice(0, 10);
    if (profile.dailyDoneDate !== today) {
      profile.dailyDoneDate = today;
      profile.hints += 2;
      profile.iq = Math.min(185, profile.iq + 1.5);
    }
  } else {
    const lvl = activeMeta.level;
    const prev = profile.stars[lvl] || 0;
    if (stars > prev) {
      profile.stars[lvl] = stars;
      profile.iq = Math.min(185, profile.iq + (prev === 0 ? 0.45 : 0.15));
    }
    if (lvl >= profile.unlockedLevel && lvl < TOTAL_LEVELS) profile.unlockedLevel = lvl + 1;
    if (lvl % 5 === 0 && prev === 0) profile.hints += 1;
  }
  saveProfile();

  document.getElementById('win-stars').textContent = '⭐'.repeat(stars) + '☆'.repeat(3 - stars);
  document.getElementById('win-title').textContent = isDaily ? 'ডেইলি টেস্ট সম্পন্ন! (+2 💡)' : `লেভেল ${activeMeta.level} সম্পন্ন!`;
  document.getElementById('win-moves').textContent = moves;
  document.getElementById('win-time').textContent = `${elapsed}s`;
  document.getElementById('win-iq').textContent = Math.round(profile.iq);
  document.getElementById('btn-win-next').classList.toggle('hidden', isDaily || activeMeta.level >= TOTAL_LEVELS);
  modalWin.classList.remove('hidden');
}

// Controls
document.getElementById('btn-reset').onclick = () => { audio.playTap(0); activeController?.reset?.(); };
document.getElementById('btn-hint').onclick = () => {
  if (profile.hints <= 0) { showToast('হিন্ট শেষ! ডেইলি টেস্ট খেলে +2 হিন্ট পান।'); return; }
  profile.hints--; saveProfile();
  document.getElementById('game-hints').textContent = profile.hints;
  audio.playHint();
  activeController?.hint?.();
};

document.getElementById('btn-play-current').onclick = () => startLevel(Math.min(TOTAL_LEVELS, profile.unlockedLevel), false);
document.getElementById('btn-open-chapters').onclick = () => {
  activeChapterIdx = Math.min(CHAPTERS.length - 1, Math.floor((profile.unlockedLevel - 1) / 50));
  renderChapters(); showScreen(scrChapters);
};
document.getElementById('btn-open-modes').onclick = () => { renderModesGallery(); modalModes.classList.remove('hidden'); };
document.getElementById('btn-close-modes').onclick = () => modalModes.classList.add('hidden');
document.getElementById('btn-daily-brain').onclick = () => startLevel(1 + (Math.floor(Date.now() / 86400000) % 500), true);
document.getElementById('btn-back-home-chapters').onclick = () => { refreshHome(); showScreen(scrHome); };
document.getElementById('btn-back-from-game').onclick = () => { refreshHome(); showScreen(scrHome); };
document.getElementById('btn-win-replay').onclick = () => startLevel(activeMeta.level, isDaily);
document.getElementById('btn-win-next').onclick = () => startLevel(Math.min(TOTAL_LEVELS, activeMeta.level + 1), false);

// Settings
function renderThemes() {
  const el = document.getElementById('theme-list');
  el.innerHTML = '';
  THEMES.forEach((t) => {
    const b = document.createElement('button');
    b.className = 'theme-btn' + (profile.theme === t.id ? ' active' : '');
    b.innerHTML = `<span class="theme-dot" style="background:${t.preview}"></span><span>${t.name}</span>`;
    b.onclick = () => { profile.theme = t.id; saveProfile(); renderThemes(); };
    el.appendChild(b);
  });
}
document.getElementById('btn-open-settings').onclick = () => {
  document.getElementById('toggle-sound').checked = profile.sound;
  document.getElementById('toggle-vibrate').checked = profile.vibrate;
  renderThemes(); modalSettings.classList.remove('hidden');
};
document.getElementById('btn-close-settings').onclick = () => modalSettings.classList.add('hidden');
document.getElementById('toggle-sound').onchange = (e) => { profile.sound = e.target.checked; saveProfile(); };
document.getElementById('toggle-vibrate').onchange = (e) => { profile.vibrate = e.target.checked; saveProfile(); };
document.getElementById('btn-reset-progress').onclick = () => {
  if (confirm('সব প্রগ্রেস মুছে ফেলতে চান?')) { profile = Object.assign({}, defaultProfile); saveProfile(); refreshHome(); modalSettings.classList.add('hidden'); }
};

saveProfile();
refreshHome();
showScreen(scrHome);
