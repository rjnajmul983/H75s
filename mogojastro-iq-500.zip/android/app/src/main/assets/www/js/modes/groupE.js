export function mountGroupE(mode, ctx) {
  const { board, rng, tier, audio, onMove, onWin, toast } = ctx;

  // 41. strat_mines (Mini Minesweeper)
  if (mode === 'strat_mines') {
    const s = 4;
    const mines = new Set();
    while (mines.size < 3) mines.add(Math.floor(rng() * s * s));
    let opened = new Set();
    const countM = (r, c) => {
      let n = 0;
      for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
        const nr = r + dr, nc = c + dc;
        if (nr >= 0 && nr < s && nc >= 0 && nc < s && mines.has(nr * s + nc)) n++;
      }
      return n;
    };
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
      for (let i = 0; i < s * s; i++) {
        const r = Math.floor(i / s), c = i % s;
        const el = document.createElement('div');
        el.className = 'tile' + (opened.has(i) ? ' path-start' : '');
        el.textContent = opened.has(i) ? (countM(r, c) || '') : '';
        el.onclick = () => {
          if (opened.has(i)) return;
          onMove();
          if (mines.has(i)) { el.classList.add('mem-wrong'); el.textContent = '💣'; audio.playError(); toast('মাইন! আবার চেষ্টা করুন'); setTimeout(() => { opened.clear(); render(); }, 600); }
          else {
            opened.add(i); audio.playTap(2); render();
            if (opened.size === s * s - mines.size) setTimeout(() => onWin(10), 200);
          }
        };
        board.appendChild(el);
      }
    };
    render();
    return { reset: () => { opened.clear(); render(); }, hint: () => { for (let i = 0; i < s * s; i++) if (!mines.has(i) && !opened.has(i)) { opened.add(i); render(); return; } } };
  }

  // 42. strat_queens (4-Queens Placement)
  if (mode === 'strat_queens') {
    const s = 4;
    let q = Array.from({ length: s }, () => Array(s).fill(0));
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
      for (let r = 0; r < s; r++) for (let c = 0; c < s; c++) {
        const el = document.createElement('div');
        el.className = 'tile' + (q[r][c] ? ' sum-selected' : '');
        el.textContent = q[r][c] ? '♛' : '';
        el.onclick = () => {
          q[r][c] = q[r][c] ? 0 : 1; onMove(); audio.playTap(3); render();
          const pos = [];
          for (let i = 0; i < s; i++) for (let j = 0; j < s; j++) if (q[i][j]) pos.push([i, j]);
          if (pos.length === s) {
            let valid = true;
            for (let a = 0; a < s; a++) for (let b = a + 1; b < s; b++) {
              if (pos[a][0] === pos[b][0] || pos[a][1] === pos[b][1] || Math.abs(pos[a][0] - pos[b][0]) === Math.abs(pos[a][1] - pos[b][1])) valid = false;
            }
            if (valid) setTimeout(() => onWin(4), 200);
            else { audio.playError(); toast('কোনো ২টি রানি এক সারি, কলাম বা কোণাকুণি থাকতে পারবে না!'); }
          }
        };
        board.appendChild(el);
      }
    };
    render();
    return { reset: () => { q = Array.from({ length: s }, () => Array(s).fill(0)); render(); }, hint: () => toast('৪×৪ বোর্ডে ৪টি রানি বসান যেন কেউ কাউকে না কাটে!') };
  }

  // 43. strat_nonogram (Pixel Nonogram)
  if (mode === 'strat_nonogram') {
    const s = 4;
    const sol = Array.from({ length: s }, () => Array.from({ length: s }, () => (rng() > 0.45 ? 1 : 0)));
    if (sol.every((r) => r.every((v) => v === 0))) sol[0][0] = 1;
    const rowC = sol.map((r) => r.reduce((a, b) => a + b, 0));
    const colC = Array.from({ length: s }, (_, c) => sol.reduce((a, r) => a + r[c], 0));
    let cur = Array.from({ length: s }, () => Array(s).fill(0));
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s + 1}, 1fr)`;
      const cr = document.createElement('div'); cr.className = 'tile sum-header'; cr.textContent = '🖼️'; board.appendChild(cr);
      for (let c = 0; c < s; c++) {
        const h = document.createElement('div');
        const v = cur.reduce((a, r) => a + r[c], 0);
        h.className = 'tile sum-header' + (v === colC[c] ? ' matched' : v > colC[c] ? ' over' : '');
        h.textContent = colC[c]; board.appendChild(h);
      }
      for (let r = 0; r < s; r++) {
        const v = cur[r].reduce((a, b) => a + b, 0);
        const rh = document.createElement('div');
        rh.className = 'tile sum-header' + (v === rowC[r] ? ' matched' : v > rowC[r] ? ' over' : '');
        rh.textContent = rowC[r]; board.appendChild(rh);
        for (let c = 0; c < s; c++) {
          const el = document.createElement('div');
          el.className = 'tile' + (cur[r][c] ? ' path-active' : '');
          el.textContent = cur[r][c] ? '■' : '';
          el.onclick = () => {
            cur[r][c] = cur[r][c] ? 0 : 1; onMove(); audio.playTap(cur[r][c] ? 4 : 1); render();
            const ok = rowC.every((t, ri) => cur[ri].reduce((a, b) => a + b, 0) === t) &&
              colC.every((t, ci) => cur.reduce((a, r) => a + r[ci], 0) === t);
            if (ok) setTimeout(() => onWin(8), 200);
          };
          board.appendChild(el);
        }
      }
    };
    render();
    return { reset: () => { cur = Array.from({ length: s }, () => Array(s).fill(0)); render(); }, hint: () => toast('প্রতিটি সারি ও কলামে ঠিক ততগুলো ঘর পূরণ করুন!') };
  }

  // 44. strat_nim (Logic Stones vs AI)
  if (mode === 'strat_nim') {
    let stones = 7 + (tier % 5) * 2;
    const initStones = stones;
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(2, 1fr)';
      const box = document.createElement('div');
      box.style.cssText = 'grid-column:1/-1; text-align:center; padding:20px; background:var(--surface); border-radius:16px;';
      box.innerHTML = `<div style="font-size:28px; letter-spacing:4px;">${'🪨'.repeat(stones)}</div><div style="margin-top:8px;font-weight:800;color:var(--accent)">বাকি পাথর: ${stones}</div>`;
      board.appendChild(box);
      [1, 2].forEach((take) => {
        const b = document.createElement('button');
        b.className = 'btn-primary'; b.textContent = `${take}টি পাথর নিন`;
        b.onclick = () => {
          if (take > stones) return;
          stones -= take; onMove(); audio.playTap(3);
          if (stones === 0) { render(); setTimeout(() => onWin(5), 200); return; }
          const aiTake = stones % 3 === 0 ? 1 : stones % 3;
          stones -= Math.min(stones, aiTake);
          toast(`AI ${aiTake}টি পাথর নিয়েছে!`);
          if (stones === 0) { audio.playError(); toast('AI জিতেছে! আবার চেষ্টা করুন'); setTimeout(() => { stones = initStones; render(); }, 900); }
          render();
        };
        board.appendChild(b);
      });
    };
    render();
    return { reset: () => { stones = initStones; render(); }, hint: () => toast('পাথরের সংখ্যা ৩-এর গুণিতক (৩, ৬, ৯) বানিয়ে দিন!') };
  }

  // 45. strat_connect (Dot Connect)
  if (mode === 'strat_connect') {
    const s = 4;
    const pts = { r1: [0, 0], r2: [3, 1], b1: [0, 3], b2: [3, 2] };
    let grid = Array.from({ length: s }, () => Array(s).fill(0)); // 1=red, 2=blue
    grid[0][0] = 1; grid[3][1] = 1; grid[0][3] = 2; grid[3][2] = 2;
    let activeColor = 1;
    const isFixed = (r, c) => (r===0&&c===0)||(r===3&&c===1)||(r===0&&c===3)||(r===3&&c===2);
    const connected = (col, st, en) => {
      const vis = new Set([`${st[0]},${st[1]}`]), q = [st];
      while (q.length) {
        const [r, c] = q.shift();
        if (r === en[0] && c === en[1]) return true;
        for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]]) {
          const nr = r + dr, nc = c + dc, k = `${nr},${nc}`;
          if (nr >= 0 && nr < s && nc >= 0 && nc < s && !vis.has(k) && grid[nr][nc] === col) { vis.add(k); q.push([nr, nc]); }
        }
      }
      return false;
    };
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
      const bar = document.createElement('div');
      bar.style.cssText = 'grid-column:1/-1; display:flex; gap:8px; margin-bottom:4px;';
      [['🔴 লাল রঙ', 1], ['🔵 নীল রঙ', 2]].forEach(([lbl, col]) => {
        const b = document.createElement('button');
        b.className = 'ctrl-btn' + (activeColor === col ? ' primary' : '');
        b.style.flex = '1'; b.textContent = lbl;
        b.onclick = () => { activeColor = col; render(); };
        bar.appendChild(b);
      });
      board.appendChild(bar);
      for (let r = 0; r < s; r++) for (let c = 0; c < s; c++) {
        const el = document.createElement('div');
        el.className = 'tile';
        if (grid[r][c] === 1) el.style.background = '#ef4444';
        else if (grid[r][c] === 2) el.style.background = '#3b82f6';
        if (isFixed(r, c)) el.textContent = '●';
        el.onclick = () => {
          if (isFixed(r, c)) return;
          grid[r][c] = grid[r][c] === activeColor ? 0 : activeColor;
          onMove(); audio.playTap(2); render();
          if (connected(1, pts.r1, pts.r2) && connected(2, pts.b1, pts.b2)) setTimeout(() => onWin(8), 200);
        };
        board.appendChild(el);
      }
    };
    render();
    return { reset: () => { grid = Array.from({ length: s }, () => Array(s).fill(0)); grid[0][0]=1; grid[3][1]=1; grid[0][3]=2; grid[3][2]=2; render(); }, hint: () => toast('লাল ও নীল দুটি পথ আলাদাভাবে জুড়ে দিন!') };
  }

  // 46 & 50: spd_schulte & spd_sort
  if (mode === 'spd_schulte' || mode === 'spd_sort') {
    const s = tier < 4 ? 3 : 4;
    const nums = mode === 'spd_schulte'
      ? Array.from({ length: s * s }, (_, i) => i + 1)
      : Array.from({ length: s * s }, (_, i) => (i + 1) * (2 + Math.floor(rng() * 3)) + Math.floor(rng() * 2));
    const sorted = nums.slice().sort((a, b) => a - b);
    const shuffled = nums.slice().sort(() => rng() - 0.5);
    let nextIdx = 0;
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
      shuffled.forEach((n) => {
        const el = document.createElement('div');
        const done = sorted.indexOf(n) < nextIdx;
        el.className = 'tile' + (done ? ' mem-correct' : '');
        el.textContent = n;
        el.onclick = () => {
          if (done) return;
          onMove();
          if (n === sorted[nextIdx]) {
            nextIdx++; audio.playTap(nextIdx); render();
            if (nextIdx === sorted.length) setTimeout(() => onWin(sorted.length), 180);
          } else audio.playError();
        };
        board.appendChild(el);
      });
    };
    render();
    return { reset: () => { nextIdx = 0; render(); }, hint: () => toast(`পরবর্তী সংখ্যা: ${sorted[nextIdx]}`) };
  }

  // 47 & 48: spd_math & spd_compare
  if (mode === 'spd_math' || mode === 'spd_compare') {
    let round = 0;
    const draw = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(2, 1fr)';
      if (mode === 'spd_compare') {
        const a1 = 4 + Math.floor(rng() * 9), b1 = 3 + Math.floor(rng() * 8);
        const v1 = a1 * b1;
        const v2 = v1 + (rng() > 0.5 ? 2 : -2);
        const hdr = document.createElement('div');
        hdr.style.cssText = 'grid-column:1/-1; text-align:center; padding:12px; font-weight:800; color:var(--accent);';
        hdr.textContent = `রাউন্ড ${round + 1}/3 — বড় মানটি বাছুন!`;
        board.appendChild(hdr);
        [[`${a1} × ${b1}`, v1], [`${v2 + 5} − 5`, v2]].forEach(([txt, val]) => {
          const b = document.createElement('button'); b.className = 'tile'; b.style.height = '96px'; b.textContent = txt;
          b.onclick = () => {
            onMove();
            if (val === Math.max(v1, v2)) { audio.playTap(4); round++; if (round >= 3) setTimeout(() => onWin(3), 180); else draw(); }
            else audio.playError();
          };
          board.appendChild(b);
        });
      } else {
        const a = 5 + Math.floor(rng() * (15 + tier * 3)), b = 3 + Math.floor(rng() * 12);
        const ans = a + b;
        const hdr = document.createElement('div');
        hdr.style.cssText = 'grid-column:1/-1; text-align:center; padding:22px; background:var(--surface); border-radius:14px; font-size:28px; font-weight:900;';
        hdr.textContent = `${a} + ${b} = ? (${round + 1}/3)`;
        board.appendChild(hdr);
        [ans, ans + 2, ans - 1, ans + 4].sort(() => rng() - 0.5).forEach((o) => {
          const btn = document.createElement('button'); btn.className = 'tile'; btn.style.height = '64px'; btn.textContent = o;
          btn.onclick = () => {
            onMove();
            if (o === ans) { audio.playTap(4); round++; if (round >= 3) setTimeout(() => onWin(3), 180); else draw(); }
            else audio.playError();
          };
          board.appendChild(btn);
        });
      }
    };
    draw();
    return { reset: () => { round = 0; draw(); }, hint: () => toast('মনোযোগ দিয়ে হিসাব করুন!') };
  }

  // 49. spd_direction (Flanker Arrow Test — 3 rounds)
  let round = 0;
  const dirs = ['⬅️', '➡️', '⬆️', '⬇️'];
  const draw = () => {
    const center = dirs[Math.floor(rng() * 4)];
    const outer = dirs[(dirs.indexOf(center) + 1) % 4];
    board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(2, 1fr)';
    const box = document.createElement('div');
    box.style.cssText = 'grid-column:1/-1; text-align:center; padding:24px; background:var(--surface); border-radius:16px; font-size:32px; letter-spacing:6px;';
    box.textContent = `${outer}${outer}${center}${outer}${outer}`;
    board.appendChild(box);
    dirs.forEach((d) => {
      const b = document.createElement('button'); b.className = 'tile'; b.style.cssText = 'height:68px; font-size:26px;'; b.textContent = d;
      b.onclick = () => {
        onMove();
        if (d === center) { audio.playTap(4); round++; if (round >= 3) setTimeout(() => onWin(3), 180); else draw(); }
        else { audio.playError(); toast('শুধু ঠিক মাঝের তীরটির দিক বাছুন!'); }
      };
      board.appendChild(b);
    });
  };
  draw();
  return { reset: () => { round = 0; draw(); }, hint: () => toast('পাশের তীরগুলো উপেক্ষা করে মাঝের তীর দেখুন!') };
}
