export function mountGroupD(mode, ctx) {
  const { board, rng, tier, audio, onMove, onWin, toast } = ctx;

  // 31. vis_odd (Odd One Out)
  if (mode === 'vis_odd') {
    const pairs = [['😀','😃'],['🔵','🟣'],['▲','△'],['★','☆'],['🔒','🔓'],['🧭','⏱️'],['◆','◇'],['🍀','🌿']];
    const [base, odd] = pairs[Math.floor(rng() * pairs.length)];
    const s = tier < 3 ? 3 : tier < 7 ? 4 : 5;
    const oddIdx = Math.floor(rng() * s * s);
    board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
    for (let i = 0; i < s * s; i++) {
      const el = document.createElement('div');
      el.className = 'tile'; el.textContent = i === oddIdx ? odd : base;
      el.onclick = () => {
        onMove();
        if (i === oddIdx) { el.classList.add('mem-correct'); setTimeout(() => onWin(1), 180); }
        else { audio.playError(); el.classList.add('mem-wrong'); }
      };
      board.appendChild(el);
    }
    return { reset: () => {}, hint: () => toast(`সারি ${Math.floor(oddIdx / s) + 1}-এ ভালো করে দেখুন!`) };
  }

  // 32. vis_color (Shade Hunter)
  if (mode === 'vis_color') {
    const s = tier < 3 ? 3 : tier < 7 ? 4 : 5;
    const hue = Math.floor(rng() * 360);
    const diff = Math.max(8, 24 - tier * 1.5);
    const oddIdx = Math.floor(rng() * s * s);
    board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
    for (let i = 0; i < s * s; i++) {
      const el = document.createElement('div');
      el.className = 'tile';
      el.style.background = `hsl(${hue}, 70%, ${i === oddIdx ? 46 + diff : 46}%)`;
      el.onclick = () => {
        onMove();
        if (i === oddIdx) { el.textContent = '✓'; setTimeout(() => onWin(1), 180); }
        else audio.playError();
      };
      board.appendChild(el);
    }
    return { reset: () => {}, hint: () => toast(`সারি ${Math.floor(oddIdx / s) + 1}-এ হালকা রঙটি আছে!`) };
  }

  // 33. vis_stroop (Stroop Color Trap — 3 rounds)
  if (mode === 'vis_stroop') {
    const cols = [{ n: 'লাল', c: '#ef4444' }, { n: 'নীল', c: '#3b82f6' }, { n: 'সবুজ', c: '#10b981' }, { n: 'হলুদ', c: '#facc15' }];
    let round = 0;
    const draw = () => {
      const word = cols[Math.floor(rng() * 4)];
      let ink = cols[Math.floor(rng() * 4)];
      if (ink === word) ink = cols[(cols.indexOf(word) + 1) % 4];
      board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(2, 1fr)';
      const box = document.createElement('div');
      box.style.cssText = `grid-column:1/-1; text-align:center; padding:26px; background:var(--surface); border-radius:16px; font-size:40px; font-weight:900; color:${ink.c};`;
      box.textContent = word.n;
      board.appendChild(box);
      cols.forEach((opt) => {
        const b = document.createElement('button');
        b.className = 'tile'; b.style.height = '64px'; b.textContent = opt.n;
        b.onclick = () => {
          onMove();
          if (opt === ink) {
            audio.playTap(4); round++;
            if (round >= 3) setTimeout(() => onWin(3), 180); else draw();
          } else { audio.playError(); toast('লেখা নয়, কালির রঙ বাছুন!'); }
        };
        board.appendChild(b);
      });
    };
    draw();
    return { reset: () => { round = 0; draw(); }, hint: () => toast('শব্দটি পড়বেন না, শুধু রঙ দেখুন!') };
  }

  // 34. vis_count (Flash Count)
  if (mode === 'vis_count') {
    const count = 4 + Math.floor(rng() * (5 + tier));
    const positions = new Set();
    while (positions.size < count) positions.add(Math.floor(rng() * 16));
    const showGrid = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(4, 1fr)';
      for (let i = 0; i < 16; i++) {
        const el = document.createElement('div');
        el.className = 'tile' + (positions.has(i) ? ' mem-flash' : '');
        el.textContent = positions.has(i) ? '★' : '';
        board.appendChild(el);
      }
      setTimeout(ask, Math.max(1200, 2200 - tier * 80));
    };
    const ask = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(2, 1fr)';
      const q = document.createElement('div');
      q.style.cssText = 'grid-column:1/-1; text-align:center; padding:18px; background:var(--surface); border-radius:14px; font-size:18px; font-weight:800;';
      q.textContent = 'মোট কয়টি তারা (★) জ্বলেছিল?';
      board.appendChild(q);
      const opts = [count, count + 1, Math.max(1, count - 1), count + 2].sort(() => rng() - 0.5);
      opts.forEach((o) => {
        const b = document.createElement('button'); b.className = 'tile'; b.style.height = '66px'; b.textContent = o;
        b.onclick = () => { onMove(); if (o === count) setTimeout(() => onWin(1), 180); else { audio.playError(); toast('ভুল! আবার দেখুন'); showGrid(); } };
        board.appendChild(b);
      });
    };
    showGrid();
    return { reset: showGrid, hint: showGrid };
  }

  // 35. vis_shadow (Rotated Shape Match)
  if (mode === 'vis_shadow') {
    const shapes = ['▙', '▛', '▟', '▜', '▞', '▚', '◤', '◥'];
    const target = shapes[Math.floor(rng() * shapes.length)];
    const opts = [target];
    while (opts.length < 4) { const s = shapes[Math.floor(rng() * shapes.length)]; if (!opts.includes(s)) opts.push(s); }
    opts.sort(() => rng() - 0.5);
    board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(2, 1fr)';
    const hdr = document.createElement('div');
    hdr.style.cssText = 'grid-column:1/-1; text-align:center; padding:24px; background:var(--surface); border-radius:16px; font-size:52px; color:var(--accent);';
    hdr.textContent = target;
    board.appendChild(hdr);
    opts.forEach((o) => {
      const b = document.createElement('button'); b.className = 'tile'; b.style.cssText = 'height:78px; font-size:38px;';
      b.textContent = o;
      b.onclick = () => { onMove(); if (o === target) setTimeout(() => onWin(1), 180); else audio.playError(); };
      board.appendChild(b);
    });
    return { reset: () => {}, hint: () => toast('উপরের আকৃতির সাথে হুবহু মিল খুঁজে নিন!') };
  }

  // 36 & 37: seq_number & seq_symbol
  if (mode === 'seq_number' || mode === 'seq_symbol') {
    let seq = [], ans = '';
    if (mode === 'seq_number') {
      const a = 2 + Math.floor(rng() * 6), d = 2 + Math.floor(rng() * (4 + tier));
      const kind = Math.floor(rng() * 3);
      if (kind === 0) { seq = [a, a+d, a+2*d, a+3*d]; ans = a + 4 * d; }
      else if (kind === 1) { seq = [a, a+d, a+3*d, a+6*d]; ans = a + 10 * d; }
      else { seq = [a, a*2, a*4, a*8]; ans = a * 16; }
    } else {
      const syms = ['▲','■','●','◆'];
      const shift = 1 + Math.floor(rng() * 3);
      seq = [syms[0], syms[shift % 4], syms[(shift * 2) % 4], syms[(shift * 3) % 4]];
      ans = syms[(shift * 4) % 4];
    }
    const opts = mode === 'seq_number'
      ? [ans, ans + 2, Math.max(1, ans - 2), ans + 4].sort(() => rng() - 0.5)
      : ['▲','■','●','◆'].sort(() => rng() - 0.5);
    board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(2, 1fr)';
    const hdr = document.createElement('div');
    hdr.style.cssText = 'grid-column:1/-1; text-align:center; padding:20px; background:var(--surface); border-radius:14px; font-size:24px; font-weight:800; letter-spacing:2px;';
    hdr.textContent = `${seq.join(' , ')} , ?`;
    board.appendChild(hdr);
    opts.forEach((o) => {
      const b = document.createElement('button'); b.className = 'tile'; b.style.height = '68px'; b.textContent = o;
      b.onclick = () => { onMove(); if (o === ans) setTimeout(() => onWin(1), 180); else audio.playError(); };
      board.appendChild(b);
    });
    return { reset: () => {}, hint: () => toast('সংখ্যা/প্রতীকগুলোর পার্থক্য বা চক্র লক্ষ্য করুন!') };
  }

  // 38. seq_mastermind (Code Breaker)
  if (mode === 'seq_mastermind') {
    const cols = ['🔴', '🟢', '🔵', '🟡'];
    const secret = Array.from({ length: 3 }, () => Math.floor(rng() * 4));
    let guess = [0, 0, 0], history = [];
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(3, 1fr)';
      const histBox = document.createElement('div');
      histBox.style.cssText = 'grid-column:1/-1; max-height:130px; overflow-y:auto; display:flex; flex-direction:column; gap:5px; margin-bottom:6px;';
      history.forEach((h) => {
        const row = document.createElement('div');
        row.style.cssText = 'display:flex; justify-content:space-between; background:var(--surface); padding:6px 12px; border-radius:10px; font-size:15px;';
        row.innerHTML = `<span>${h.g.map((i) => cols[i]).join(' ')}</span><span>🟢${h.exact} &nbsp; 🟡${h.near}</span>`;
        histBox.appendChild(row);
      });
      board.appendChild(histBox);
      guess.forEach((ci, idx) => {
        const el = document.createElement('div'); el.className = 'tile'; el.textContent = cols[ci];
        el.onclick = () => { guess[idx] = (guess[idx] + 1) % 4; audio.playTap(2); render(); };
        board.appendChild(el);
      });
      const sub = document.createElement('button');
      sub.className = 'btn-primary'; sub.style.cssText = 'grid-column:1/-1; margin-top:6px;';
      sub.textContent = 'কোড চেক করুন 🔐';
      sub.onclick = () => {
        onMove();
        let exact = 0, near = 0;
        const sRem = [], gRem = [];
        for (let i = 0; i < 3; i++) {
          if (guess[i] === secret[i]) exact++;
          else { sRem.push(secret[i]); gRem.push(guess[i]); }
        }
        gRem.forEach((g) => { const f = sRem.indexOf(g); if (f >= 0) { near++; sRem.splice(f, 1); } });
        history.unshift({ g: guess.slice(), exact, near });
        if (exact === 3) { audio.playConnect(); render(); setTimeout(() => onWin(5), 220); }
        else { audio.playTap(0); render(); }
      };
      board.appendChild(sub);
    };
    render();
    return { reset: () => { history = []; guess = [0, 0, 0]; render(); }, hint: () => toast(`প্রথম রঙটি হলো: ${cols[secret[0]]}`) };
  }

  // 39. seq_binary (Binary Switch)
  if (mode === 'seq_binary') {
    const bitsCount = tier < 4 ? 4 : 5;
    const target = 3 + Math.floor(rng() * (Math.pow(2, bitsCount) - 4));
    let bits = Array(bitsCount).fill(0);
    const render = () => {
      const val = bits.reduce((a, b, i) => a + b * Math.pow(2, bitsCount - 1 - i), 0);
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${bitsCount}, 1fr)`;
      const hdr = document.createElement('div');
      hdr.style.cssText = 'grid-column:1/-1; text-align:center; padding:14px; background:var(--surface); border-radius:14px; font-size:18px; font-weight:800;';
      hdr.innerHTML = `টার্গেট: <b style="color:var(--accent-2)">${target}</b> &nbsp;|&nbsp; মান: <b style="color:var(--accent)">${val}</b>`;
      board.appendChild(hdr);
      bits.forEach((b, i) => {
        const w = Math.pow(2, bitsCount - 1 - i);
        const el = document.createElement('div');
        el.className = 'tile' + (b ? ' sum-selected' : '');
        el.innerHTML = `<div style="text-align:center"><div>${b}</div><small style="font-size:10px;opacity:0.75">${w}</small></div>`;
        el.onclick = () => {
          bits[i] = b ? 0 : 1; onMove(); audio.playTap(bits[i] ? 4 : 1); render();
          const nv = bits.reduce((a, x, idx) => a + x * Math.pow(2, bitsCount - 1 - idx), 0);
          if (nv === target) setTimeout(() => onWin(bitsCount), 200);
        };
        board.appendChild(el);
      });
    };
    render();
    return { reset: () => { bits = Array(bitsCount).fill(0); render(); }, hint: () => toast('নিচের ছোট সংখ্যাগুলোর যোগফল টার্গেটের সমান করুন!') };
  }

  // 40. seq_cipher (Symbol Cipher Equations)
  const a = 2 + Math.floor(rng() * 7), b = 2 + Math.floor(rng() * 7);
  const ans = a + b;
  const opts = [ans, ans + 1, Math.max(2, ans - 1), ans + 3].sort(() => rng() - 0.5);
  board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(2, 1fr)';
  const eq = document.createElement('div');
  eq.style.cssText = 'grid-column:1/-1; text-align:center; padding:16px; background:var(--surface); border-radius:14px; font-size:19px; font-weight:800; line-height:1.7;';
  eq.innerHTML = `🍎 + 🍎 = ${a * 2}<br/>🍎 + ⭐ = ${a + b}<br/>⭐ + 🍎 = ?`;
  board.appendChild(eq);
  opts.forEach((o) => {
    const btn = document.createElement('button'); btn.className = 'tile'; btn.style.height = '64px'; btn.textContent = o;
    btn.onclick = () => { onMove(); if (o === ans) setTimeout(() => onWin(1), 180); else audio.playError(); };
    board.appendChild(btn);
  });
  return { reset: () => {}, hint: () => toast(`🍎 = ${a}, এবার ⭐ বের করুন!`) };
}
