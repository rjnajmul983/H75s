export class AudioEngine {
  constructor() {
    this.ctx = null;
    this.muted = false;
    this.vibrateEnabled = true;
  }
  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (AC) this.ctx = new AC();
  }
  haptic(p = 16) {
    if (this.vibrateEnabled && navigator.vibrate) { try { navigator.vibrate(p); } catch (_) {} }
  }
  playTone(freq, dur = 0.1, type = 'sine', vol = 0.13, delay = 0) {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    g.gain.setValueAtTime(0.001, now);
    g.gain.exponentialRampToValueAtTime(vol, now + 0.015);
    g.gain.exponentialRampToValueAtTime(0.001, now + dur);
    osc.connect(g); g.connect(this.ctx.destination);
    osc.start(now); osc.stop(now + dur + 0.02);
  }
  playTap(o = 0) { this.haptic(12); this.playTone(440 + o * 28, 0.08, 'triangle', 0.12); }
  playRotate() { this.haptic(14); this.playTone(520, 0.07, 'sine', 0.11); this.playTone(660, 0.06, 'sine', 0.08, 0.03); }
  playConnect() { this.haptic(22); this.playTone(587, 0.12, 'sine', 0.13); this.playTone(880, 0.16, 'sine', 0.11, 0.06); }
  playError() { this.haptic([35, 35, 35]); this.playTone(190, 0.15, 'sawtooth', 0.11); this.playTone(150, 0.16, 'sawtooth', 0.1, 0.08); }
  playHint() { this.haptic(20); this.playTone(784, 0.12, 'sine', 0.12); this.playTone(1046, 0.18, 'sine', 0.12, 0.09); }
  playWin() { this.haptic([40, 40, 80]); [523.25, 659.25, 783.99, 1046.5].forEach((n, i) => this.playTone(n, 0.22, 'triangle', 0.14, i * 0.08)); }
}
