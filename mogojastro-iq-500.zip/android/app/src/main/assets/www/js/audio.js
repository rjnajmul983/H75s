export class AudioEngine {
  constructor() {
    this.ctx = null;
    this.muted = false;
    this.vibrateEnabled = true;
  }

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return;
    }
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (AudioCtx) this.ctx = new AudioCtx();
  }

  haptic(pattern = 18) {
    if (this.vibrateEnabled && navigator.vibrate) {
      try { navigator.vibrate(pattern); } catch (_) {}
    }
  }

  playTone(freq, duration = 0.1, type = 'sine', vol = 0.14, delay = 0) {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(vol, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  playTap(pitchOffset = 0) {
    this.haptic(12);
    this.playTone(440 + pitchOffset * 32, 0.08, 'triangle', 0.12);
  }

  playRotate() {
    this.haptic(14);
    this.playTone(520, 0.07, 'sine', 0.11);
    this.playTone(660, 0.06, 'sine', 0.08, 0.03);
  }

  playConnect() {
    this.haptic(22);
    this.playTone(587.33, 0.12, 'sine', 0.13);
    this.playTone(880, 0.16, 'sine', 0.11, 0.06);
  }

  playError() {
    this.haptic([35, 35, 35]);
    this.playTone(190, 0.16, 'sawtooth', 0.11);
    this.playTone(150, 0.18, 'sawtooth', 0.11, 0.09);
  }

  playHint() {
    this.haptic(20);
    this.playTone(784, 0.12, 'sine', 0.12);
    this.playTone(1046.5, 0.18, 'sine', 0.12, 0.09);
  }

  playWin() {
    this.haptic([40, 40, 80]);
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((n, i) => this.playTone(n, 0.24, 'triangle', 0.14, i * 0.09));
  }
}
