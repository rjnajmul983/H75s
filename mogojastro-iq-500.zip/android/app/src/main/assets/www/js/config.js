export const TOTAL_LEVELS = 500;

export const CHAPTERS = [
  { id: 1, nameBn: 'অধ্যায় ১: সূচনা', subtitle: 'সহজ ৩×৩ ওয়ার্ম-আপ', range: [1, 50], badge: '🌱' },
  { id: 2, nameBn: 'অধ্যায় ২: জাগরণ', subtitle: 'মৌলিক লজিক ও প্যাটার্ন', range: [51, 100], badge: '💡' },
  { id: 3, nameBn: 'অধ্যায় ৩: বিশ্লেষণ', subtitle: '৪×৪ গ্রিড চ্যালেঞ্জ', range: [101, 150], badge: '🔍' },
  { id: 4, nameBn: 'অধ্যায় ৪: কৌশল', subtitle: 'মাল্টি-স্টেপ পাজল', range: [151, 200], badge: '♟️' },
  { id: 5, nameBn: 'অধ্যায় ৫: গভীরতা', subtitle: '৪×৪ ও ৫×৫ মিক্স', range: [201, 250], badge: '🧠' },
  { id: 6, nameBn: 'অধ্যায় ৬: চক্রব্যূহ', subtitle: 'জটিল সার্কিট ও পাথ', range: [251, 300], badge: '🌀' },
  { id: 7, nameBn: 'অধ্যায় ৭: অন্তর্দৃষ্টি', subtitle: '৫×৫ হাই-লজিক', range: [301, 350], badge: '⚡' },
  { id: 8, nameBn: 'অধ্যায় ৮: মাস্টারমাইন্ড', subtitle: 'উচ্চতর মেমোরি ও গণনা', range: [351, 400], badge: '🔥' },
  { id: 9, nameBn: 'অধ্যায় ৯: জিনিয়াস জোন', subtitle: '৫×৫ ও ৬×৬ এক্সপার্ট', range: [401, 450], badge: '💎' },
  { id: 10, nameBn: 'অধ্যায় ১০: গ্র্যান্ডমাস্টার', subtitle: 'চূড়ান্ত আইকিউ পরীক্ষা', range: [451, 500], badge: '👑' }
];

export const MODE_INFO = {
  path: {
    id: 'path',
    icon: '〰️',
    nameBn: 'ওয়ান-লাইন পাথ',
    hintBn: 'সবুজ ঘর থেকে শুরু করে হাত না তুলে প্রতিটি খোলা ঘরে একবার করে যান।'
  },
  lights: {
    id: 'lights',
    icon: '💡',
    nameBn: 'কোয়ান্টাম ফ্লিপ',
    hintBn: 'যেকোনো ঘরে ট্যাপ করলে সেটি ও পাশের ঘরগুলোর আলো বদলে যায়। সব আলো জ্বালান।'
  },
  pipes: {
    id: 'pipes',
    icon: '🔌',
    nameBn: 'সার্কিট রোটেট',
    hintBn: 'পাইপগুলোতে ট্যাপ করে ঘোরান এবং ব্যাটারি (⚡) থেকে সব কোরে (💎) সংযোগ দিন।'
  },
  sumgrid: {
    id: 'sumgrid',
    icon: '🔢',
    nameBn: 'সাম ম্যাট্রিক্স',
    hintBn: 'ঘরগুলো সিলেক্ট করুন যাতে প্রতিটি সারি ও কলামের যোগফল পাশের সংখ্যার সমান হয়।'
  },
  memory: {
    id: 'memory',
    icon: '🧩',
    nameBn: 'মেমোরি ম্যাট্রিক্স',
    hintBn: 'জ্বলে ওঠা নকশা বা ক্রম মনে রাখুন এবং আলো নিভে গেলে ঠিক সেই ঘরগুলোতে ট্যাপ করুন।'
  }
};

export const RANKS = [
  { minIq: 85, title: 'নবীন অভিযাত্রী', icon: '🌱' },
  { minIq: 100, title: 'চিন্তাবিদ', icon: '💡' },
  { minIq: 115, title: 'লজিক বিশ্লেষক', icon: '🔍' },
  { minIq: 130, title: 'কৌশলী মাস্টার', icon: '♟️' },
  { minIq: 145, title: 'সুপার জিনিয়াস', icon: '⚡' },
  { minIq: 165, title: 'গ্র্যান্ডমাস্টার', icon: '👑' }
];

export const THEMES = [
  { id: 'cyber', name: 'সাইবার ডার্ক', preview: 'linear-gradient(135deg,#0f172a,#06b6d4)' },
  { id: 'emerald', name: 'এমেরাল্ড', preview: 'linear-gradient(135deg,#064e3b,#10b981)' },
  { id: 'indigo', name: 'রয়্যাল ইন্ডিগো', preview: 'linear-gradient(135deg,#1e1b4b,#8b5cf6)' },
  { id: 'light', name: 'মিনিমাল লাইট', preview: 'linear-gradient(135deg,#f8fafc,#3b82f6)' }
];

// Deterministic PRNG (Mulberry32) so every level 1..500 is 100% consistent
export function createRng(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Determine mode & difficulty parameters for any level 1..500
export function getLevelMeta(levelNum) {
  const modes = ['path', 'lights', 'pipes', 'sumgrid', 'memory'];
  const mode = modes[(levelNum - 1) % modes.length];
  const progress = (levelNum - 1) / (TOTAL_LEVELS - 1); // 0.0 -> 1.0

  let size = 3;
  if (levelNum > 40 && levelNum <= 180) size = 4;
  else if (levelNum > 180 && levelNum <= 380) size = 5;
  else if (levelNum > 380) size = mode === 'lights' || mode === 'sumgrid' ? 5 : 6;

  // Special gentle intro for first 25 levels
  if (levelNum <= 25) size = 3;

  const chapterIdx = Math.min(CHAPTERS.length - 1, Math.floor((levelNum - 1) / 50));
  return {
    level: levelNum,
    mode,
    size,
    progress,
    chapter: CHAPTERS[chapterIdx]
  };
}
