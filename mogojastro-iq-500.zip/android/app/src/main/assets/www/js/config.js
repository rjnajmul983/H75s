export const TOTAL_LEVELS = 500;

export const CHAPTERS = [
  { id: 1, nameBn: 'অধ্যায় ১: সূচনা', subtitle: '৫০টি মোডের প্রথম পরিচয়', range: [1, 50], badge: '🌱' },
  { id: 2, nameBn: 'অধ্যায় ২: জাগরণ', subtitle: 'লজিক ও প্যাটার্ন', range: [51, 100], badge: '💡' },
  { id: 3, nameBn: 'অধ্যায় ৩: বিশ্লেষণ', subtitle: 'মাঝারি গ্রিড চ্যালেঞ্জ', range: [101, 150], badge: '🔍' },
  { id: 4, nameBn: 'অধ্যায় ৪: কৌশল', subtitle: 'মাল্টি-স্টেপ পাজল', range: [151, 200], badge: '♟️' },
  { id: 5, nameBn: 'অধ্যায় ৫: গভীরতা', subtitle: 'উন্নত স্পেশিয়াল লজিক', range: [201, 250], badge: '🧠' },
  { id: 6, nameBn: 'অধ্যায় ৬: চক্রব্যূহ', subtitle: 'জটিল সার্কিট ও কোড', range: [251, 300], badge: '🌀' },
  { id: 7, nameBn: 'অধ্যায় ৭: অন্তর্দৃষ্টি', subtitle: 'হাই-স্পিড আইকিউ', range: [301, 350], badge: '⚡' },
  { id: 8, nameBn: 'অধ্যায় ৮: মাস্টারমাইন্ড', subtitle: 'এক্সপার্ট মেমোরি ও গণনা', range: [351, 400], badge: '🔥' },
  { id: 9, nameBn: 'অধ্যায় ৯: জিনিয়াস জোন', subtitle: 'চ্যালেঞ্জিং ব্রেইন টেস্ট', range: [401, 450], badge: '💎' },
  { id: 10, nameBn: 'অধ্যায় ১০: গ্র্যান্ডমাস্টার', subtitle: 'চূড়ান্ত আইকিউ পরীক্ষা', range: [451, 500], badge: '👑' }
];

export const MODES = [
  // Group A (1-10): Path & Flip
  { id: 'path_classic', icon: '〰️', nameBn: 'ওয়ান-লাইন পাথ', hintBn: 'সবুজ ঘর থেকে শুরু করে হাত না তুলে প্রতিটি খোলা ঘরে একবার যান।' },
  { id: 'flip_plus', icon: '💡', nameBn: 'কোয়ান্টাম ফ্লিপ', hintBn: 'ট্যাপ করলে ঘর ও পাশের ঘরগুলোর আলো বদলে যায়। সব আলো জ্বালান।' },
  { id: 'pipe_circuit', icon: '🔌', nameBn: 'সার্কিট রোটেট', hintBn: 'পাইপ ঘুরিয়ে ব্যাটারি (⚡) থেকে সব কোরে (💎) সংযোগ দিন।' },
  { id: 'math_sumgrid', icon: '🔢', nameBn: 'সাম ম্যাট্রিক্স', hintBn: 'ঘর সিলেক্ট করুন যাতে প্রতিটি সারি ও কলামের যোগফল মেলে।' },
  { id: 'mem_pattern', icon: '🧩', nameBn: 'মেমোরি ম্যাট্রিক্স', hintBn: 'জ্বলে ওঠা নকশা মনে রাখুন এবং আলো নিভে গেলে ঠিক সেই ঘরগুলোতে ট্যাপ করুন।' },
  { id: 'path_ice', icon: '🧊', nameBn: 'আইস স্লাইড', hintBn: 'দিক বাটনে ট্যাপ করে বরফে স্লাইড করে লাল পতাকায় (🏁) পৌঁছান।' },
  { id: 'vis_odd', icon: '👀', nameBn: 'ভিন্নটা খুঁজুন', hintBn: 'সবগুলোর মাঝে লুকিয়ে থাকা ১টি ভিন্ন প্রতীক খুঁজে ট্যাপ করুন।' },
  { id: 'slide_15', icon: '🔳', nameBn: 'স্লাইডিং নম্বর', hintBn: 'খালি ঘরে টাইল সরিয়ে ১, ২, ৩... ক্রমে সাজান।' },
  { id: 'seq_binary', icon: '💻', nameBn: 'বাইনারি সুইচ', hintBn: '0 এবং 1 বিট সুইচ করে উপরের ডেসিমাল টার্গেট সংখ্যা তৈরি করুন।' },
  { id: 'spd_schulte', icon: '⚡', nameBn: 'শুল্টে টেবিল', hintBn: '১ থেকে শুরু করে শেষ সংখ্যা পর্যন্ত দ্রুত ক্রমানুসারে ট্যাপ করুন।' },

  { id: 'path_knight', icon: '♞', nameBn: 'নাইট জার্নি', hintBn: 'দাবার ঘোড়ার (L-আকৃতি) চালে প্রতিটি সোনালী তারকা (★) সংগ্রহ করুন।' },
  { id: 'flip_cross', icon: '✨', nameBn: 'এক্স-ফ্লিপ (×)', hintBn: 'ট্যাপ করলে ঘর ও কোণাকুণি ঘরগুলোর আলো বদলায়। সব আলো জ্বালান।' },
  { id: 'rot_align', icon: '🧭', nameBn: 'অ্যারো অ্যালাইন', hintBn: 'ট্যাপ করে প্রতিটি তীরকে উপরের দিকে (⬆️) ঘোরান।' },
  { id: 'math_prodgrid', icon: '✖️', nameBn: 'গুণফল ম্যাট্রিক্স', hintBn: 'ঘর সিলেক্ট করুন যাতে প্রতিটি সারির গুণফল পাশের সংখ্যার সমান হয়।' },
  { id: 'mem_order', icon: '🔢', nameBn: 'সিকোয়েন্স রিকল', hintBn: 'সংখ্যাগুলোর ক্রম (১, ২, ৩...) মনে রাখুন এবং ঠিক সেই ক্রমে ট্যাপ করুন।' },
  { id: 'vis_color', icon: '🎨', nameBn: 'শেড হান্টার', hintBn: 'রঙের সূক্ষ্ম পার্থক্য চিনে ১টি ভিন্ন রঙের ঘর খুঁজে বের করুন।' },
  { id: 'slide_swap', icon: '🔀', nameBn: 'মিনিমাম সোয়াপ', hintBn: 'যেকোনো ২টি ঘরে ট্যাপ করে অদল-বদল করুন এবং ছোট থেকে বড় সাজান।' },
  { id: 'seq_number', icon: '📈', nameBn: 'নম্বর সিরিজ', hintBn: 'সংখ্যার ধারার লজিক বুঝে প্রশ্নবোধক (?) স্থানের সঠিক সংখ্যা বাছুন।' },
  { id: 'strat_mines', icon: '💣', nameBn: 'মিনি মাইনসুইপার', hintBn: 'সংখ্যার সূত্র ধরে মাইন (💣) এড়িয়ে সব নিরাপদ ঘর খুলুন।' },
  { id: 'spd_compare', icon: '⚖️', nameBn: 'বড় কোনটি?', hintBn: 'দুটি গাণিতিক রাশির মধ্যে যেটি বড় সেটিতে ট্যাপ করুন (৩ রাউন্ড)।' },

  { id: 'path_checkpoint', icon: '🚩', nameBn: 'চেকপয়েন্ট পাথ', hintBn: 'সব ঘর ভিজিট করুন এবং ১ → ২ → ৩ চেকপয়েন্টগুলো ক্রমানুসারে পার হন।' },
  { id: 'flip_rowcol', icon: '🔦', nameBn: 'লেজার রো-কল', hintBn: 'ট্যাপ করলে পুরো সারি ও কলামের আলো বদলায়। সব আলো জ্বালান।' },
  { id: 'rot_gear', icon: '⚙️', nameBn: 'গিয়ার লক', hintBn: 'ট্যাপ করলে ঘর ও ডানপাশের ঘর একসাথে ঘোরে। সবগুলো 🔓 করুন।' },
  { id: 'math_latin', icon: '🟦', nameBn: 'মিনি সুডোকু', hintBn: 'খালি ঘরে ট্যাপ করে ১–N বসান যেন কোনো সারি বা কলামে সংখ্যা রিপিট না হয়।' },
  { id: 'mem_reverse', icon: '⏪', nameBn: 'রিভার্স মেমোরি', hintBn: '১, ২, ৩... ক্রম মনে রাখুন, কিন্তু উল্টো দিক থেকে (বড় থেকে ছোট) ট্যাপ করুন!' },
  { id: 'vis_stroop', icon: '🔴', nameBn: 'স্ট্রুপ ট্র্যাপ', hintBn: 'লেখা কী আছে তা নয়—লেখাটির "রঙ" কোনটি তা নিচে থেকে বাছুন (৩ রাউন্ড)!' },
  { id: 'slide_water', icon: '🧪', nameBn: 'ওয়াটার সর্ট', hintBn: 'এক টিউব থেকে আরেক টিউবে রঙ ঢেলে প্রতিটি টিউবে একই রঙ আলাদা করুন।' },
  { id: 'seq_mastermind', icon: '🔐', nameBn: 'কোড ব্রেকার', hintBn: 'রঙ বাছাই করে গোপন কোড ভাঙুন। 🟢 = সঠিক স্থান, 🟡 = ভুল স্থান।' },
  { id: 'strat_queens', icon: '♛', nameBn: 'কুইন প্লেসমেন্ট', hintBn: 'প্রতিটি সারি ও কলামে ১টি করে রানি (♛) বসান যেন কেউ কাউকে আক্রমণ না করে।' },
  { id: 'spd_direction', icon: '⬅️', nameBn: 'ফ্ল্যাঙ্কার অ্যারো', hintBn: 'পাশের তীরগুলো উপেক্ষা করে ঠিক মাঝের তীরটির দিক বাছুন (৩ রাউন্ড)!' },

  { id: 'path_maze', icon: '🗺️', nameBn: 'ডার্ক মেজ', hintBn: 'অন্ধকার গোলকধাঁধায় টর্চলাইট নিয়ে 🏁 লক্ষ্যে পৌঁছান।' },
  { id: 'flip_tricolor', icon: '🚦', nameBn: 'ট্রাই-কালার ফ্লিপ', hintBn: 'ট্যাপ করলে রঙ বদলায়: লাল → হলুদ → সবুজ। সব ঘর সবুজ করুন!' },
  { id: 'pipe_dual', icon: '🔋', nameBn: 'ডুয়াল পাওয়ার', hintBn: 'পাইপ ঘুরিয়ে দুটি ব্যাটারি (⚡) থেকে সব কোরে (💎) পাওয়ার দিন।' },
  { id: 'math_calc24', icon: '🎯', nameBn: 'টার্গেট মেকার', hintBn: 'নিচের সংখ্যাগুলো যোগ/বিয়োগ করে ঠিক টার্গেট সংখ্যাটি তৈরি করুন।' },
  { id: 'mem_pairs', icon: '🃏', nameBn: 'কার্ড ম্যাচ', hintBn: 'কার্ড উল্টে একই জোড়া প্রতীকগুলো মিলিয়ে ফেলুন।' },
  { id: 'vis_count', icon: '🌟', nameBn: 'ফ্ল্যাশ কাউন্ট', hintBn: 'বোর্ডে ক্ষণিকের জন্য তারা (★) জ্বলবে—মোট কয়টি তারা ছিল গুনুন!' },
  { id: 'slide_tower', icon: '🗼', nameBn: 'টাওয়ার অফ হ্যানয়', hintBn: 'সব ডিস্ক প্রথম স্তম্ভ থেকে শেষ স্তম্ভে নিন (বড় ডিস্ক ছোটর উপর নয়)।' },
  { id: 'seq_cipher', icon: '🍎', nameBn: 'সিম্বল সাইফার', hintBn: 'প্রথম দুটি সমীকরণ থেকে প্রতীকের মান বের করে তৃতীয়টির উত্তর দিন।' },
  { id: 'strat_nonogram', icon: '🖼️', nameBn: 'পিক্সেল ননোগ্রাম', hintBn: 'সারি ও কলামের সংখ্যার সূত্র ধরে সঠিক ঘরগুলো পূরণ করুন।' },
  { id: 'spd_math', icon: '➕', nameBn: 'র‍্যাপিড ম্যাথ', hintBn: 'দ্রুত ৩টি মানসিক অঙ্কের সঠিক উত্তর দিন।' },

  { id: 'flip_mirror', icon: '🪞', nameBn: 'মিরর সিমেট্রি', hintBn: 'বাম পাশের নকশা দেখে ডান পাশে তার হুবহু আয়নার প্রতিচ্ছবি আঁকুন।' },
  { id: 'rot_pattern', icon: '🔄', nameBn: 'কোয়াড্র্যান্ট রোটেট', hintBn: '২×২ ব্লক ঘুরিয়ে সব রঙিন টাইল উপরের সারিতে নিয়ে আসুন।' },
  { id: 'math_balance', icon: '⚖️', nameBn: 'ওজন ব্যালেন্স', hintBn: 'বাম পাল্লার ওজনের সমান করতে ডান পাল্লায় সঠিক ওজনগুলো সিলেক্ট করুন।' },
  { id: 'mem_simon', icon: '🎵', nameBn: 'নিয়ন সাইমন', hintBn: 'রঙিন প্যাডগুলোর জ্বলার ছন্দ মনে রাখুন এবং ঠিক সেই ক্রমে ট্যাপ করুন।' },
  { id: 'vis_shadow', icon: '🔷', nameBn: 'শ্যাডো ম্যাচ', hintBn: 'ঘোরানো ছায়ার সাথে হুবহু মিল আছে এমন আকৃতিটি খুঁজে বাছুন।' },
  { id: 'slide_color', icon: '🌈', nameBn: 'কালার রো সর্ট', hintBn: 'পাশাপাশি ঘর অদল-বদল করে প্রতিটি সারিতে একই রঙ সাজান।' },
  { id: 'seq_symbol', icon: '📐', nameBn: 'প্যাটার্ন ম্যাট্রিক্স', hintBn: '৩×৩ প্যাটার্নের লজিক বুঝে ফাঁকা ঘরের সঠিক প্রতীক বাছুন।' },
  { id: 'strat_nim', icon: '🪨', nameBn: 'লজিক স্টোনস', hintBn: 'পালা করে ১ বা ২টি পাথর নিন। যে শেষ পাথর নেবে সে জিতবে!' },
  { id: 'strat_connect', icon: '🔴', nameBn: 'ডট কানেক্ট', hintBn: 'একই রঙের দুটি বিন্দুর মাঝে পথ তৈরি করুন যেন লাইন ক্রস না হয়।' },
  { id: 'spd_sort', icon: '📊', nameBn: 'অ্যাসেন্ডিং ট্যাপ', hintBn: 'ছড়িয়ে থাকা সংখ্যাগুলো ছোট থেকে বড় ক্রমানুসারে ট্যাপ করুন।' }
];

export const RANKS = [
  { minIq: 85, title: 'নবীন অভিযাত্রী', icon: '🌱' },
  { minIq: 100, title: 'চিন্তাবিদ', icon: '💡' },
  { minIq: 115, title: 'লজিক বিশ্লেষক', icon: '🔍' },
  { minIq: 130, title: 'কৌশলী মাস্টার', icon: '♟️' },
  { minIq: 145, title: 'সুপার জিনিয়াস', icon: '⚡' },
  { minIq: 165, title: 'গ্র্যান্ডমাস্টার', icon: '👑' }
];

export const THEMES = [
  { id: 'cyber', name: 'সাইবার ডার্ক', preview: 'linear-gradient(135deg,#0f172a,#06b6d4)' },
  { id: 'emerald', name: 'এমেরাল্ড', preview: 'linear-gradient(135deg,#064e3b,#10b981)' },
  { id: 'indigo', name: 'রয়্যাল ইন্ডিগো', preview: 'linear-gradient(135deg,#1e1b4b,#8b5cf6)' },
  { id: 'light', name: 'মিনিমাল লাইট', preview: 'linear-gradient(135deg,#f8fafc,#3b82f6)' }
];

export function createRng(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function getLevelMeta(levelNum) {
  const modeObj = MODES[(levelNum - 1) % MODES.length];
  const tier = Math.floor((levelNum - 1) / 50); // 0..9 difficulty tier
  const chapter = CHAPTERS[Math.min(CHAPTERS.length - 1, tier)];
  return { level: levelNum, mode: modeObj.id, modeObj, tier, chapter };
}
