export function mountGroupC(mode, ctx) {
  const { board, rng, tier, audio, onMove, onWin, toast } = ctx;

  // 21. slide_15 (Sliding Number Puzzle)
  if (mode === 'slide_15') {
    const s = tier < 5 ? 3 : 4;
    const arr = Array.from({ length: s * s }, (_, i) => (i + 1) % (s * s));
    let empty = s * s - 1;
    const dirs = [-s, s, -1, 1];
    for (let i = 0; i < 20 + tier * 6; i++) {
      const er = Math.floor(empty / s), ec = empty % s;
      const nbs = [];
      if (er > 0) nbs.push(empty - s);
      if (er < s - 1) nbs.push(empty + s);
      if (ec > 0) nbs.push(empty - 1);
      if (ec < s - 1) nbs.push(empty + 1);
      const pick = nbs[Math.floor(rng() * nbs.length)];
      [arr[empty], arr[pick]] = [arr[pick], arr[empty]];
      empty = pick;
    }
    const init = arr.slice();
    let cur = arr.slice();
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
      cur.forEach((v, idx) => {
        const el = document.createElement('div');
        el.className = 'tile' + (v === 0 ? ' wall' : v === idx + 1 ? ' path-start' : '');
        el.textContent = v || '';
        el.onclick = () => {
          const z = cur.indexOf(0);
          const r1 = Math.floor(idx / s), c1 = idx % s, r2 = Math.floor(z / s), c2 = z % s;
          if (Math.abs(r1 - r2) + Math.abs(c1 - c2) === 1) {
            [cur[idx], cur[z]] = [cur[z], cur[idx]]; onMove(); audio.playTap(2); render();
            if (cur.every((x, i) => x === (i + 1) % (s * s))) setTimeout(() => onWin(15), 200);
          }
        };
        board.appendChild(el);
      });
    };
    render();
    return { reset: () => { cur = init.slice(); render(); }, hint: () => toast('খালি ঘরের পাশের টাইল ট্যাপ করে ১, ২, ৩... সাজান!') };
  }

  // 22 & 23: slide_swap & slide_color
  if (mode === 'slide_swap' || mode === 'slide_color') {
    const isColor = mode === 'slide_color';
    const s = 3;
    const cols = ['#ef4444', '#06b6d4', '#10b981'];
    const target = isColor ? [0,0,0, 1,1,1, 2,2,2] : Array.from({ length: 9 }, (_, i) => i + 1);
    const init = target.slice().sort(() => rng() - 0.5);
    let cur = init.slice(), first = -1;
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
      cur.forEach((v, idx) => {
        const el = document.createElement('div');
        el.className = 'tile' + (first === idx ? ' hint-glow' : '');
        if (isColor) { el.style.background = cols[v]; el.textContent = ''; }
        else { el.textContent = v; if (v === idx + 1) el.classList.add('path-start'); }
        el.onclick = () => {
          if (first === -1) { first = idx; audio.playTap(1); render(); }
          else if (first === idx) { first = -1; render(); }
          else {
            [cur[first], cur[idx]] = [cur[idx], cur[first]];
            first = -1; onMove(); audio.playRotate(); render();
            const ok = isColor
              ? [0, 3, 6].every((st) => cur[st] === cur[st + 1] && cur[st + 1] === cur[st + 2])
              : cur.every((x, i) => x === i + 1);
            if (ok) setTimeout(() => onWin(7), 200);
          }
        };
        board.appendChild(el);
      });
    };
    render();
    return { reset: () => { cur = init.slice(); first = -1; render(); }, hint: () => toast('২টি ঘরে ট্যাপ করে তাদের অবস্থান বদল করুন!') };
  }

  // 24. slide_tower (Tower of Hanoi)
  if (mode === 'slide_tower') {
    const disks = tier < 4 ? 3 : 4;
    let pegs = [Array.from({ length: disks }, (_, i) => disks - i), [], []];
    let sel = -1;
    const colors = ['#ef4444', '#f59e0b', '#10b981', '#06b6d4'];
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(3, 1fr)';
      pegs.forEach((peg, pi) => {
        const col = document.createElement('div');
        col.className = 'tile' + (sel === pi ? ' hint-glow' : '');
        col.style.cssText = 'aspect-ratio:auto; height:180px; flex-direction:column-reverse; justify-content:flex-start; gap:5px; padding:10px;';
        peg.forEach((d) => {
          const bar = document.createElement('div');
          bar.style.cssText = `height:22px; width:${32 + d * 16}%; background:${colors[d - 1]}; border-radius:6px;`;
          col.appendChild(bar);
        });
        col.onclick = () => {
          if (sel === -1) { if (peg.length) { sel = pi; audio.playTap(2); render(); } }
          else if (sel === pi) { sel = -1; render(); }
          else {
            const top = pegs[sel][pegs[sel].length - 1];
            const dstTop = peg[peg.length - 1];
            if (!dstTop || top < dstTop) {
              peg.push(pegs[sel].pop()); sel = -1; onMove(); audio.playRotate(); render();
              if (pegs[2].length === disks) setTimeout(() => onWin(Math.pow(2, disks) - 1), 200);
            } else { audio.playError(); sel = -1; toast('বড় ডিস্ক ছোট ডিস্কের উপর বসবে না!'); render(); }
          }
        };
        board.appendChild(col);
      });
    };
    render();
    return { reset: () => { pegs = [Array.from({ length: disks }, (_, i) => disks - i), [], []]; sel = -1; render(); }, hint: () => toast('সব ডিস্ক ডানের ৩য় স্তম্ভে নিয়ে যান!') };
  }

  // 25. slide_water (Water Sort Tubes)
  if (mode === 'slide_water') {
    const cols = ['#ef4444', '#06b6d4', '#facc15', '#10b981'];
    const numColors = tier < 4 ? 3 : 4;
    const pool = [];
    for (let c = 0; c < numColors; c++) for (let k = 0; k < 3; k++) pool.push(c);
    pool.sort(() => rng() - 0.5);
    const init = Array.from({ length: numColors }, (_, i) => pool.slice(i * 3, i * 3 + 3));
    init.push([]); init.push([]);
    let tubes = init.map((t) => t.slice());
    let sel = -1;
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${tubes.length}, 1fr)`;
      tubes.forEach((t, ti) => {
        const el = document.createElement('div');
        el.className = 'tile' + (sel === ti ? ' hint-glow' : '');
        el.style.cssText = 'aspect-ratio:auto; height:165px; flex-direction:column-reverse; justify-content:flex-start; gap:4px; padding:6px; border-radius:8px 8px 24px 24px;';
        t.forEach((cIdx) => {
          const drop = document.createElement('div');
          drop.style.cssText = `width:100%; height:38px; background:${cols[cIdx]}; border-radius:8px;`;
          el.appendChild(drop);
        });
        el.onclick = () => {
          if (sel === -1) { if (t.length) { sel = ti; audio.playTap(2); render(); } }
          else if (sel === ti) { sel = -1; render(); }
          else {
            const src = tubes[sel];
            const top = src[src.length - 1];
            if (t.length < 3 && (t.length === 0 || t[t.length - 1] === top)) {
              t.push(src.pop()); sel = -1; onMove(); audio.playConnect(); render();
              const ok = tubes.every((tb) => tb.length === 0 || (tb.length === 3 && tb.every((x) => x === tb[0])));
              if (ok) setTimeout(() => onWin(12), 200);
            } else { audio.playError(); sel = -1; render(); }
          }
        };
        board.appendChild(el);
      });
    };
    render();
    return { reset: () => { tubes = init.map((t) => t.slice()); sel = -1; render(); }, hint: () => toast('একই রঙের উপর অথবা খালি টিউবে ঢালুন!') };
  }

  // 26, 27, 28: mem_pattern, mem_order, mem_reverse
  if (mode === 'mem_pattern' || mode === 'mem_order' || mode === 'mem_reverse') {
    const s = tier < 3 ? 3 : 4;
    const count = Math.min(s * s - 2, 3 + Math.floor(tier / 2));
    const seq = [];
    const used = new Set();
    while (seq.length < count) {
      const r = Math.floor(rng() * s), c = Math.floor(rng() * s), k = `${r},${c}`;
      if (!used.has(k)) { used.add(k); seq.push([r, c]); }
    }
    let phase = 'preview', picked = [];
    const ordered = mode !== 'mem_pattern';
    const isRev = mode === 'mem_reverse';
    const seqMap = new Map(seq.map(([r, c], i) => [`${r},${c}`, i]));

    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = `repeat(${s}, 1fr)`;
      const pSet = new Set(picked.map(([r, c]) => `${r},${c}`));
      for (let r = 0; r < s; r++) for (let c = 0; c < s; c++) {
        const k = `${r},${c}`;
        const el = document.createElement('div');
        el.className = 'tile';
        if (phase === 'preview') {
          if (seqMap.has(k)) { el.classList.add('mem-flash'); el.textContent = ordered ? seqMap.get(k) + 1 : '✦'; }
        } else {
          if (pSet.has(k)) { el.classList.add('mem-correct'); el.textContent = ordered ? seqMap.get(k) + 1 : '✓'; }
          el.onclick = () => {
            if (pSet.has(k)) return;
            onMove();
            const expIdx = isRev ? seq.length - 1 - picked.length : picked.length;
            const ok = ordered ? seqMap.get(k) === expIdx : seqMap.has(k);
            if (ok) {
              picked.push([r, c]); audio.playTap(picked.length * 2); render();
              if (picked.length === seq.length) setTimeout(() => onWin(seq.length), 200);
            } else {
              el.classList.add('mem-wrong'); el.textContent = '✕'; audio.playError();
              toast('ভুল! আবার দেখুন...');
              setTimeout(startPreview, 650);
            }
          };
        }
        board.appendChild(el);
      }
    };
    const startPreview = () => {
      phase = 'preview'; picked = []; render();
      setTimeout(() => { phase = 'input'; render(); }, Math.max(1500, 2800 - tier * 120));
    };
    startPreview();
    return { reset: startPreview, hint: () => startPreview() };
  }

  // 29. mem_pairs (Card Match Pairs)
  if (mode === 'mem_pairs') {
    const syms = ['🧠','⚡','💎','🔥','🌟','🎯','🚀','👑'];
    const pairs = tier < 4 ? 6 : 8;
    const deck = [...syms.slice(0, pairs), ...syms.slice(0, pairs)].sort(() => rng() - 0.5);
    let open = [], matched = new Set(), lock = false;
    const render = () => {
      board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(4, 1fr)';
      deck.forEach((sym, i) => {
        const el = document.createElement('div');
        const isUp = open.includes(i) || matched.has(i);
        el.className = 'tile' + (matched.has(i) ? ' mem-correct' : isUp ? ' mem-flash' : '');
        el.textContent = isUp ? sym : '?';
        el.onclick = () => {
          if (lock || isUp) return;
          open.push(i); onMove(); audio.playTap(2); render();
          if (open.length === 2) {
            lock = true;
            const [a, b] = open;
            if (deck[a] === deck[b]) {
              matched.add(a); matched.add(b); open = []; lock = false; audio.playConnect(); render();
              if (matched.size === deck.length) setTimeout(() => onWin(pairs * 2), 200);
            } else {
              setTimeout(() => { open = []; lock = false; render(); }, 550);
            }
          }
        };
        board.appendChild(el);
      });
    };
    render();
    return { reset: () => { open = []; matched.clear(); render(); }, hint: () => toast('একই জোড়া প্রতীকগুলো মনে রাখুন!') };
  }

  // 30. mem_simon (Neon Simon)
  const pads = [{ c: '#ef4444', f: 330 }, { c: '#10b981', f: 440 }, { c: '#3b82f6', f: 554 }, { c: '#f59e0b', f: 659 }];
  const len = 3 + Math.min(4, Math.floor(tier / 2));
  const seq = Array.from({ length: len }, () => Math.floor(rng() * 4));
  let step = 0, playing = true, lit = -1;
  const render = () => {
    board.innerHTML = ''; board.style.gridTemplateColumns = 'repeat(2, 1fr)';
    pads.forEach((p, i) => {
      const el = document.createElement('div');
      el.className = 'tile';
      el.style.cssText = `height:120px; background:${p.c}; opacity:${lit === i ? 1 : 0.42}; border-color:${lit === i ? '#fff' : 'transparent'};`;
      el.onclick = () => {
        if (playing) return;
        lit = i; audio.playTone(p.f, 0.14, 'triangle', 0.15); render();
        setTimeout(() => { lit = -1; render(); }, 180);
        onMove();
        if (seq[step] === i) {
          step++;
          if (step === seq.length) setTimeout(() => onWin(seq.length), 240);
        } else { audio.playError(); toast('ভুল ছন্দ! আবার শুনুন...'); setTimeout(playSeq, 600); }
      };
      board.appendChild(el);
    });
  };
  const playSeq = () => {
    playing = true; step = 0; render();
    seq.forEach((pIdx, idx) => {
      setTimeout(() => {
        lit = pIdx; audio.playTone(pads[pIdx].f, 0.18, 'triangle', 0.14); render();
        setTimeout(() => { lit = -1; render(); if (idx === seq.length - 1) playing = false; }, 320);
      }, 480 * (idx + 1));
    });
  };
  playSeq();
  return { reset: playSeq, hint: playSeq };
}
