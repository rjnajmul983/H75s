const CACHE = 'neurogrid-iq-v1';
const ASSETS = ['./', './index.html', './manifest.json', './icon.svg', './css/style.css', './js/main.js', './js/config.js', './js/audio.js', './js/generator.js'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS))); self.skipWaiting(); });
self.addEventListener('fetch', (e) => { e.respondWith(caches.match(e.request).then((c) => c || fetch(e.request))); });
